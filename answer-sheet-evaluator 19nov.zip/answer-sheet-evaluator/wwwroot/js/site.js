// Site-wide JavaScript functionality

// Import Bootstrap
const bootstrap = window.bootstrap

// Initialize tooltips
document.addEventListener("DOMContentLoaded", () => {
  // Initialize Bootstrap tooltips
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))

  // Initialize Bootstrap popovers
  var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
  var popoverList = popoverTriggerList.map((popoverTriggerEl) => new bootstrap.Popover(popoverTriggerEl))

  // Auto-hide alerts after 5 seconds
  setTimeout(() => {
    var alerts = document.querySelectorAll(".alert-dismissible")
    alerts.forEach((alert) => {
      var bsAlert = new bootstrap.Alert(alert)
      bsAlert.close()
    })
  }, 5000)
})

// Utility functions
function showLoading(element) {
  if (element) {
    element.disabled = true
    const originalText = element.innerHTML
    element.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Loading...'
    element.setAttribute("data-original-text", originalText)
  }
}

function hideLoading(element) {
  if (element) {
    element.disabled = false
    const originalText = element.getAttribute("data-original-text")
    if (originalText) {
      element.innerHTML = originalText
      element.removeAttribute("data-original-text")
    }
  }
}

function showAlert(message, type = "info") {
  const alertContainer = document.createElement("div")
  alertContainer.className = `alert alert-${type} alert-dismissible fade show`
  alertContainer.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `

  const container = document.querySelector(".container-fluid main") || document.body
  container.insertBefore(alertContainer, container.firstChild)

  // Auto-hide after 5 seconds
  setTimeout(() => {
    const bsAlert = new bootstrap.Alert(alertContainer)
    bsAlert.close()
  }, 5000)
}

// AJAX helper functions
function makeAjaxRequest(url, options = {}) {
  const defaultOptions = {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
    },
  }

  const finalOptions = { ...defaultOptions, ...options }

  return fetch(url, finalOptions)
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      return response.json()
    })
    .catch((error) => {
      console.error("AJAX request failed:", error)
      showAlert("An error occurred while processing your request.", "danger")
      throw error
    })
}

// Form validation helpers
function validateForm(formElement) {
  const inputs = formElement.querySelectorAll("input[required], select[required], textarea[required]")
  let isValid = true

  inputs.forEach((input) => {
    if (!input.value.trim()) {
      input.classList.add("is-invalid")
      isValid = false
    } else {
      input.classList.remove("is-invalid")
    }
  })

  return isValid
}

// PDF.js configuration
const pdfjsLib = window.pdfjsLib
if (typeof pdfjsLib !== "undefined") {
  pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js"
}

// Export functions for use in other scripts
window.AnswerSheetEvaluator = {
  showLoading,
  hideLoading,
  showAlert,
  makeAjaxRequest,
  validateForm,
}
