﻿            let evaluationData = [];
            let blankPages = [];
            let selectedQuestion = null;
            let selectedMark = null;
            let selectedTool = 'mark';
            let pdfDoc = null;
            let currentPage = 1;
            let scale = 1.0;
            let totalPages = 1;

            const subject = model.subject;
            const rollNumber = model.RollNumber;
            const pdfUrl = 'https://cc.icsi.edu/impdocs/help%20document.pdf';
            const totalQuestions = model.totalQuestions;

            $(document).ready(function() {
                initializeMarksPanel();
                initializeToolsPanel();
                initializeQuestionsPanel();
                loadPDF();
                loadExistingEvaluation();
                bindEvents();
            });

            function initializeMarksPanel() {
                const marksPanel = $('#marksPanel');
                const markOptions = [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10];

                markOptions.forEach(mark => {
                    const button = $(`
                        <button type="button" class="btn btn-outline-primary btn-sm mark-btn" data-mark="${mark}">
                            ${mark}
                        </button>
                    `);
                    marksPanel.append(button);
                });
            }

            function initializeToolsPanel() {
                const toolsPanel = $('#toolsPanel');
                const tools = [
                    { id: 'mark', label: 'Mark', icon: 'fas fa-edit', color: 'primary' },
                    { id: 'tick', label: 'Tick', icon: 'fas fa-check', color: 'success' },
                    { id: 'cross', label: 'Cross', icon: 'fas fa-times', color: 'danger' },
                    { id: 'line', label: 'Line', icon: 'fas fa-minus', color: 'warning' },
                    { id: 'delete', label: 'Delete', icon: 'fas fa-trash', color: 'secondary' }
                ];

                tools.forEach(tool => {
                    const button = $(`
                        <button type="button" class="btn btn-outline-${tool.color} tool-btn" data-tool="${tool.id}">
                            <i class="${tool.icon} me-2"></i>${tool.label}
                        </button>
                    `);
                    toolsPanel.append(button);
                });

                $('.tool-btn[data-tool="mark"]').addClass('active');
            }

            function initializeQuestionsPanel() {
                const questionsPanel = $('#questionsPanel');

                for (let i = 1; i <= totalQuestions; i++) {
                    const button = $(`
                        <button type="button" class="btn btn-outline-secondary question-btn" data-question="${i}">
                            <div class="d-flex justify-content-between align-items-center">
                                <span>Q${i}</span>
                                <span class="badge badge-secondary question-marks" data-question="${i}">0/10</span>
                            </div>
                        </button>
                    `);
                    questionsPanel.append(button);
                }
            }

            function loadPDF() {
                $('#pdfViewer').html(`
                    <div class="d-flex align-items-center justify-content-center h-100">
                        <div class="text-center">
                            <div class="loading-spinner mb-3"></div>
                            <h5>Loading PDF...</h5>
                            <p class="text-muted">Please wait while we load the answer sheet</p>
                        </div>
                    </div>
                `);

                if (typeof pdfjsLib !== 'undefined') {
                   pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
                }

                let pdfUrlToLoad = pdfUrl;

                if (!pdfUrlToLoad || pdfUrlToLoad.trim() === '') {
                    pdfUrlToLoad = 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf';
                }

                const loadingTask = pdfjsLib.getDocument({
                    url: pdfUrlToLoad,
                    cMapUrl: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/cmaps/',
                    cMapPacked: true,
                    enableXfa: true
                });

                loadingTask.promise.then(function(pdf) {
                    pdfDoc = pdf;
                    totalPages = pdf.numPages;
                    currentPage = 1;

                    console.log('PDF loaded successfully. Total pages:', totalPages);

                    updatePageControls();

                    renderPage(currentPage);

                }).catch(function(error) {
                    console.error('Error loading PDF:', error);
                });
            }





            function renderPage(pageNumber) {
                if (!pdfDoc) return;

                pdfDoc.getPage(pageNumber).then(function(page) {
                    const canvas = document.createElement('canvas');
                    const context = canvas.getContext('2d');




                    const viewport = page.getViewport({ scale: scale });
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;

                    const container = $(`
                        <div class="pdf-page-container" style="position: relative; overflow:auto; max-height:100vh;">
                            <canvas id="pdfCanvas" style="border: 1px solid #ddd; box-shadow: 0 2px 8px rgba(0,0,0,0.1);"></canvas>
                        </div>
                    `);

                    $('#pdfViewer').empty().append(container);
                    container.find('#pdfCanvas').replaceWith(canvas);

                    // Render PDF page
                    const renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };

                    page.render(renderContext).promise.then(function() {
                        $(canvas).on('click', function(event) {
                            handleCanvasClick(event, canvas);
                        });

                        renderAnnotations(pageNumber, canvas);
                    });

                    updatePageControls();
                });
            }

            function handleCanvasClick(event, canvas) {
                if (blankPages.includes(currentPage)) {
                    alert('This page is marked as blank');
                    return;
                }

                const rect = canvas.getBoundingClientRect();
                const x = ((event.clientX - rect.left) / rect.width) * 100;
                const y = ((event.clientY - rect.top) / rect.height) * 100;

                if (selectedTool === 'delete') {
                    // Find and remove annotation at clicked location
                    const clickedAnnotation = evaluationData.find(item => {
                        if (!item.coordinates || item.coordinates.pageNumber !== currentPage) return false;
                        const distance = Math.sqrt(
                            Math.pow(item.coordinates.x - x, 2) +
                            Math.pow(item.coordinates.y - y, 2)
                        );
                        return distance < 5; // Within 5% distance
                    });

                    if (clickedAnnotation) {
                        evaluationData = evaluationData.filter(item => item.id !== clickedAnnotation.id);
                        updateUI();
                        renderAnnotations(currentPage, canvas);
                    }
                    return;
                }

                if (!selectedQuestion) {
                    alert('Please select a question number first');
                    return;
                }

                if (selectedTool === 'mark' && selectedMark === null) {
                    alert('Please select marks first');
                    return;
                }

                // Check if total marks for question would exceed 10
                if (selectedTool === 'mark') {
                    const currentTotal = evaluationData
                        .filter(item => item.questionNumber === selectedQuestion && item.type === 'mark')
                        .reduce((sum, item) => sum + item.marks, 0);

                    if (currentTotal + selectedMark > 10) {
                        alert(`Cannot add ${selectedMark} marks. Total would exceed 10 marks for Question ${selectedQuestion}`);
                        return;
                    }
                }

                const newEvaluation = {
                    id: Date.now() + Math.random(),
                    questionNumber: selectedQuestion,
                    type: selectedTool,
                    marks: selectedTool === 'mark' ? selectedMark : 0,
                    coordinates: { x, y, pageNumber: currentPage },
                    timestamp: new Date().toISOString()
                };

                evaluationData.push(newEvaluation);
                updateUI();
                renderAnnotations(currentPage, canvas);

                if (selectedTool === 'mark') {
                    $('.mark-btn').removeClass('active');
                    selectedMark = null;
                    updateStatusIndicator();
                }
            }

            function renderAnnotations(pageNumber, canvas) {
                $('.annotation-overlay').remove();

                const pageAnnotations = evaluationData.filter(item =>
                    item.coordinates && item.coordinates.pageNumber === pageNumber
                );

                const canvasRect = canvas.getBoundingClientRect();
                const container = $(canvas).parent();

                pageAnnotations.forEach(annotation => {
                    const x = (annotation.coordinates.x / 100) * canvas.width;
                    const y = (annotation.coordinates.y / 100) * canvas.height;

                    let annotationHtml = '';
                    let className = 'annotation-overlay';

                    switch (annotation.type) {
                        case 'mark':
                            annotationHtml = `Q${annotation.questionNumber}: ${annotation.marks}`;
                            className += ' annotation-mark';
                            break;
                        case 'tick':
                            annotationHtml = '<i class="fas fa-check"></i>';
                            className += ' annotation-tick';
                            break;
                        case 'cross':
                            annotationHtml = '<i class="fas fa-times"></i>';
                            className += ' annotation-cross';
                            break;
                        case 'line':
                            annotationHtml = '<i class="fas fa-minus"></i>';
                            className += ' annotation-line';
                            break;
                    }

                    const annotationElement = $(`
                        <div class="${className}" style="
                            position: absolute;
                            left: ${x}px;
                            top: ${y}px;
                            transform: translate(-50%, -50%);
                            z-index: 10;
                            pointer-events: none;
                        ">
                            ${annotationHtml}
                        </div>
                    `);

                    container.append(annotationElement);
                });
            }

            function loadExistingEvaluation() {
                $.get('/Evaluation/GetEvaluationData', { subject, rollNumber })
                    .done(function(data) {
                        if (data.evaluationData) {
                            evaluationData = data.evaluationData;
                            blankPages = data.blankPages || [];
                            updateUI();
                        }
                    })
                    .fail(function() {
                        console.error('Failed to load existing evaluation');
                    });
            }

            function bindEvents() {
                $(document).on('click', '.mark-btn', function() {
                    $('.mark-btn').removeClass('active');
                    $(this).addClass('active');
                    selectedMark = parseFloat($(this).data('mark'));
                    updateStatusIndicator();
                });

                $(document).on('click', '.tool-btn', function() {
                    $('.tool-btn').removeClass('active');
                    $(this).addClass('active');
                    selectedTool = $(this).data('tool');
                    updateStatusIndicator();
                });

                $(document).on('click', '.question-btn', function() {
                    $('.question-btn').removeClass('active');
                    $(this).addClass('active');
                    selectedQuestion = parseInt($(this).data('question'));
                    updateStatusIndicator();
                });

                $('#submitBtn').click(function() {
                    submitEvaluation();
                });

                $('#blankPagesBtn').click(function() {
                    showModal();
                });

                $('#saveBlankPages').click(function() {
                    closeModal();
                    updateUI();
                });

                $('#prevPage').click(() => {
                    if (currentPage > 1) {
                        currentPage--;
                        renderPage(currentPage);
                    }
                });

                $('#nextPage').click(() => {
                    if (currentPage < totalPages) {
                        currentPage++;
                        renderPage(currentPage);
                    }
                });

                $('#zoomIn').click(() => {
                    if (scale < 2.0) {
                        scale += 0.2;
                        updateZoom();
                        renderPage(currentPage);
                    }
                });

                $('#zoomOut').click(() => {
                    if (scale > 0.5) {
                        scale -= 0.2;
                        updateZoom();
                        renderPage(currentPage);
                    }
                });
            }

            function updateUI() {
                const totalMarks = evaluationData
                    .filter(item => item.type === 'mark')
                    .reduce((sum, item) => sum + item.marks, 0);
                $('#totalMarks').text(totalMarks);

                const evaluatedQuestions = new Set(
                    evaluationData
                        .filter(item => item.type === 'mark')
                        .map(item => item.questionNumber)
                ).size;
                $('#evaluatedCount').text(evaluatedQuestions);
                $('#questionsEvaluated').text(evaluatedQuestions);

                const questionMarks = {};
                evaluationData
                    .filter(item => item.type === 'mark')
                    .forEach(item => {
                        if (!questionMarks[item.questionNumber]) {
                            questionMarks[item.questionNumber] = 0;
                        }
                        questionMarks[item.questionNumber] += item.marks;
                    });

                $('.question-marks').each(function() {
                    const questionNum = $(this).data('question');
                    const marks = questionMarks[questionNum] || 0;
                    $(this).text(`${marks}/10`);

                    const button = $(this).closest('.question-btn');
                    if (marks > 0) {
                        button.removeClass('btn-outline-secondary').addClass('btn-outline-success');
                        $(this).removeClass('badge-secondary').addClass('badge-success');
                    } else {
                        button.removeClass('btn-outline-success').addClass('btn-outline-secondary');
                        $(this).removeClass('badge-success').addClass('badge-secondary');
                    }
                });

                $('#blankPagesCount').text(blankPages.length);
            }

            function updateStatusIndicator() {
                let message = '';
                let icon = 'fas fa-info-circle';

                if (selectedTool === 'delete') {
                    message = 'Delete Mode: Click on any mark to remove it';
                    icon = 'fas fa-trash';
                } else if (selectedTool === 'mark') {
                    if (selectedQuestion && selectedMark !== null) {
                        message = `Ready to mark: Question ${selectedQuestion} with ${selectedMark} marks - Click on PDF`;
                        icon = 'fas fa-check-circle';
                    } else {
                        message = 'Select question number and marks, then click on PDF';
                        icon = 'fas fa-exclamation-circle';
                    }
                } else {
                    if (selectedQuestion) {
                        message = `Ready to add ${selectedTool}: Question ${selectedQuestion} - Click on PDF`;
                        icon = 'fas fa-check-circle';
                    } else {
                        message = `Select question number, then click on PDF to add ${selectedTool}`;
                        icon = 'fas fa-exclamation-circle';
                    }
                }

                $('#statusIndicator').html(`
                    <p class="mb-0">
                        <i class="${icon} me-2"></i>
                        ${message}
                    </p>
                `);
            }

            function updatePageControls() {
                $('#currentPageNum').text(currentPage);
                $('#totalPages').text(totalPages);
                $('#prevPage').prop('disabled', currentPage <= 1);
                $('#nextPage').prop('disabled', currentPage >= totalPages);

                if (blankPages.includes(currentPage)) {
                    $('#blankPageIndicator').show();
                } else {
                    $('#blankPageIndicator').hide();
                }
            }

            function updateZoom() {
                $('#zoomLevel').text(Math.round(scale * 100) + '%');
                $('#zoomOut').prop('disabled', scale <= 0.5);
                $('#zoomIn').prop('disabled', scale >= 2.0);
            }

            function submitEvaluation() {
                if (evaluationData.length === 0) {
                    alert('No evaluation data to submit');
                    return;
                }

                const payload = {
                    subject,
                    rollNumber,
                    evaluationData,
                    blankPages,
                    totalQuestions,
                    submittedAt: new Date().toISOString()
                };

                const submitBtn = $('#submitBtn');
                const originalText = submitBtn.html();
                submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i>Submitting...');

                $.ajax({
                    url: '/Evaluation/SaveEvaluation',
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(payload)
                })
                .done(function(response) {
                    if (response.success) {
                        alert('Evaluation submitted successfully!');
                        window.location.href = '/Home';
                    } else {
                        alert('Error: ' + response.message);
                    }
                })
                .fail(function() {
                    alert('Failed to submit evaluation');
                })
                .always(function() {
                    submitBtn.prop('disabled', false).html(originalText);
                });
            }

            function showModal() {
                $('#pageSelectionModal').show();
                loadPageThumbnails();
            }

            function closeModal() {
                $('#pageSelectionModal').hide();
            }

            function loadPageThumbnails() {
                const grid = $('#pageSelectionGrid');
                grid.empty();

                if (!pdfDoc) {
                    grid.html('<div class="col-12 text-center"><p class="text-muted">PDF not loaded</p></div>');
                    return;
                }

                for (let i = 1; i <= totalPages; i++) {
                    const isBlank = blankPages.includes(i);
                    const pageDiv = $(`
                        <div class="col-md-2 col-sm-3 col-4 mb-3">
                            <div class="page-thumbnail ${isBlank ? 'selected' : ''}" data-page="${i}">
                                <div class="thumbnail-content">
                                    <div class="page-preview" id="thumbnail-${i}">
                                        <div class="loading-spinner-small"></div>
                                    </div>
                                    <div class="page-number">Page ${i}</div>
                                    ${isBlank ? '<div class="selected-indicator"><i class="fas fa-times"></i></div>' : ''}
                                </div>
                            </div>
                        </div>
                    `);
                    grid.append(pageDiv);

                    generateThumbnail(i);
                }

                $('.page-thumbnail').click(function() {
                    const pageNum = parseInt($(this).data('page'));
                    toggleBlankPage(pageNum);
                });
            }

            function generateThumbnail(pageNumber) {
                if (!pdfDoc) return;

                pdfDoc.getPage(pageNumber).then(function(page) {
                    const canvas = document.createElement('canvas');
                    const context = canvas.getContext('2d');

                    const viewport = page.getViewport({ scale: 0.3 });
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;
                    canvas.style.width = '100%';
                    canvas.style.height = 'auto';
                    canvas.style.maxHeight = '120px';
                    canvas.style.border = '1px solid #ddd';
                    canvas.style.borderRadius = '4px';

                    const renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };

                    page.render(renderContext).promise.then(function() {
                        $(`#thumbnail-${pageNumber}`).empty().append(canvas);
                    });
                }).catch(function(error) {
                    $(`#thumbnail-${pageNumber}`).html('<i class="fas fa-file-alt fa-2x text-muted"></i>');
                });
            }

            function toggleBlankPage(pageNumber) {
                const index = blankPages.indexOf(pageNumber);
                const thumbnail = $(`.page-thumbnail[data-page="${pageNumber}"]`);

                if (index > -1) {
                    blankPages.splice(index, 1);
                    thumbnail.removeClass('selected');
                    thumbnail.find('.selected-indicator').remove();
                } else {
                    blankPages.push(pageNumber);
                    thumbnail.addClass('selected');
                    thumbnail.append('<div class="selected-indicator"><i class="fas fa-times"></i></div>');
                }

                $('#blankPagesCount').text(blankPages.length);
            }

            updateStatusIndicator();
  