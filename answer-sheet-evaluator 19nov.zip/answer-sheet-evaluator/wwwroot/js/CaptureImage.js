﻿const video = document.getElementById('webcam');
const canvas = document.getElementById('canvas');
const context = canvas.getContext('2d');
const constraints = { video: true };
 
async function getIPAddress() {
    try {
        const response = await fetch('https://api.ipify.org?format=json');
        const data = await response.json();
        return data.ip;
    } catch (error) {
        console.error('Error fetching IP address:', error);
        return 'unknown_ip';
    }
}
 
async function captureAndSendImage() {
    if (!video || video.readyState !== video.HAVE_ENOUGH_DATA) {
        console.warn('Webcam not ready or unavailable');
        return;
    }
     
    const loginId = document.getElementById('username')?.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '') || 'anonymous';
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-'); 
    const ipAddress = await getIPAddress();
    const fileName = `${loginId}_${ipAddress}_${timestamp}.png`;
     
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = canvas.toDataURL('image/png');
     
    try {
        const response = await fetch('/api/upload-image', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                image: imageData,
                fileName: fileName
            })
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        console.log(`Image ${fileName} uploaded successfully`);
    } catch (error) {
        console.error('Error uploading image:', error);
    }
}
 
navigator.mediaDevices.getUserMedia(constraints)
    .then((stream) => {
        video.srcObject = stream; 
        setInterval(captureAndSendImage, 1800000);
    })
    .catch((err) => {
        console.error('Error accessing webcam:', err);
        alert('Failed to access webcam. Please ensure camera permissions are granted.');
    });
     
window.addEventListener('beforeunload', () => {
    if (video.srcObject) {
        video.srcObject.getVideoTracks().forEach(track => track.stop());
    }
});