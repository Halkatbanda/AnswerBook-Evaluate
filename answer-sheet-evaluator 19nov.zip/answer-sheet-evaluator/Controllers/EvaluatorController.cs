﻿using Microsoft.AspNetCore.Mvc;
using AnswerSheetEvaluator.Models;
using Microsoft.Data.SqlClient;
using System.Data;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace AnswerSheetEvaluator.Controllers
{
    [Authorize (Roles ="EVALUATOR")]
    public class EvaluatorController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;
        
        public EvaluatorController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IActionResult> Dashboard()
        {
            // Get evaluator ID from session or claims (you can adjust based on your auth system)
            var evaluatorId = User?.FindFirst("UserId")?.Value ?? "evaluator_1"; // Placeholder
            var evaluatorName = User?.FindFirst("UserName")?.Value ?? "Evaluator"; // Placeholder

            var model = new EvaluatorDashboardViewModel
            {
                EvaluatorId = evaluatorId,
                EvaluatorName = evaluatorName,
                AssignedSubjects = await GetAssignedSubjectsAsync(evaluatorId),
                CompletedCopies = await GetCompletedCopiesAsync(evaluatorId),
                Statistics = await GetEvaluatorStatisticsAsync(evaluatorId)
            };

            return View(model);
        }

        public async Task<IActionResult> SubjectDetails(string subject)
        {
            var searchTerm = HttpContext.Request.Query["search"].ToString();
            var statusFilter = HttpContext.Request.Query["status"].ToString();

            var evaluatorId = User?.FindFirst("UserId")?.Value ?? "evaluator_1";
            var model = await GetSubjectDetailsAsync(evaluatorId, subject, searchTerm, statusFilter);

            ViewBag.SearchTerm = searchTerm;
            ViewBag.Status = statusFilter;

            return View(model);
        }

        public async Task<IActionResult> ViewEvaluatedCopy(string subject, string rollNumber)
        {
            var model = await GetEvaluatedCopyDetailsAsync(subject, rollNumber);
            return View(model);
        }

        public async Task<IActionResult> DownloadEvaluatedPDF(string subject, string rollNumber)
        {
            try
            {
                var pdfPath = await GetEvaluatedPdfPathAsync(subject, rollNumber);
                if (System.IO.File.Exists(pdfPath))
                {
                    var fileBytes = await System.IO.File.ReadAllBytesAsync(pdfPath);
                    var fileName = $"{subject}_{rollNumber}_evaluated.pdf";
                    return File(fileBytes, "application/pdf", fileName);
                }

                TempData["Error"] = "PDF file not found";
                return RedirectToAction("Dashboard");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error downloading PDF: {ex.Message}";
                return RedirectToAction("Dashboard");
            }
        }

        public async Task<IActionResult> StartNewEvaluation(string subject)
        {
            try
            {
                var evaluatorId = User?.FindFirst("sub")?.Value ?? "evaluator_1";
                var randomStudent = await GetRandomStudentForEvaluationAsync(evaluatorId, subject);

                if (randomStudent == null)
                {
                    TempData["Warning"] = "No pending copies available for evaluation in this subject.";
                    return RedirectToAction("SubjectDetails", new { subject });
                }

                // Redirect to evaluation page with the random student
                return RedirectToAction("Evaluate", "Evaluation", new
                {
                    rollNumber = randomStudent.RollNumber,
                    subject = subject,
                    documentId = randomStudent.Id
                });
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error starting new evaluation: {ex.Message}";
                return RedirectToAction("SubjectDetails", new { subject });
            }
        }

        private async Task<List<AssignedSubjectViewModel>> GetAssignedSubjectsAsync(string evaluatorId)
        {
            var subjects = new List<AssignedSubjectViewModel>();

            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("sp_GetEvaluatorAssignedSubjects", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@EvaluatorId", evaluatorId);

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                var completedCopies = Convert.ToInt32(reader["CompletedCopies"]);
                var totalCopies = Convert.ToInt32(reader["TotalCopies"]);
                var completionPercentage = totalCopies > 0 ? (double)completedCopies / totalCopies * 100 : 0;

                subjects.Add(new AssignedSubjectViewModel
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Subject = reader["Subject"].ToString(),
                    TotalCopies = totalCopies,
                    CompletedCopies = completedCopies,
                    PendingCopies = totalCopies - completedCopies,
                    CompletionPercentage = completionPercentage,
                    AssignedDate = Convert.ToDateTime(reader["AssignedDate"])
                });
            }

            return subjects;
        }

        private async Task<List<CompletedCopyViewModel>> GetCompletedCopiesAsync(string evaluatorId)
        {
            var completedCopies = new List<CompletedCopyViewModel>();

            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("sp_GetEvaluatorCompletedCopies", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@EvaluatorId", evaluatorId);
            command.Parameters.AddWithValue("@TopRecords", 10); // Get latest 10

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                completedCopies.Add(new CompletedCopyViewModel
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Subject = reader["Subject"].ToString(),
                    RollNumber = reader["RollNumber"].ToString(),
                    StudentName = reader["StudentName"]?.ToString(),
                    TotalMarks = Convert.ToInt32(reader["TotalMarks"] ?? 100),
                    MarksObtained = Convert.ToDecimal(reader["MarksObtained"]),
                    Percentage = Convert.ToDecimal(reader["Percentage"]),
                    EvaluatedQuestions = Convert.ToInt32(reader["EvaluatedQuestions"]),
                    TotalQuestions = Convert.ToInt32(reader["TotalQuestions"]),
                    EvaluatedAt = Convert.ToDateTime(reader["EvaluatedAt"]),
                    PdfPath = reader["PdfPath"]?.ToString()
                });
            }

            return completedCopies;
        }

        private async Task<EvaluatorStatisticsViewModel> GetEvaluatorStatisticsAsync(string evaluatorId)
        {
            var stats = new EvaluatorStatisticsViewModel();

            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("sp_GetEvaluatorStatistics", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@EvaluatorId", evaluatorId);

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                stats.TotalAssignedSubjects = Convert.ToInt32(reader["TotalAssignedSubjects"]);
                stats.TotalCopiesToEvaluate = Convert.ToInt32(reader["TotalCopiesToEvaluate"]);
                stats.CompletedEvaluations = Convert.ToInt32(reader["CompletedEvaluations"]);
                stats.PendingEvaluations = Convert.ToInt32(reader["PendingEvaluations"]);
                stats.CompletionRate = stats.TotalCopiesToEvaluate > 0 ?
                    Math.Round((double)stats.CompletedEvaluations / stats.TotalCopiesToEvaluate * 100, 1) : 0;
                stats.AverageMarksGiven = Convert.ToDouble(reader["AverageMarksGiven"] ?? 0);
                stats.EvaluationsThisWeek = Convert.ToInt32(reader["EvaluationsThisWeek"] ?? 0);
                stats.EvaluationsThisMonth = Convert.ToInt32(reader["EvaluationsThisMonth"] ?? 0);
            }

            return stats;
        }

        private async Task<EvaluationDetailsViewModel> GetSubjectDetailsAsync(string evaluatorId, string subject, string searchTerm = "", string statusFilter = "all")
        {
            var model = new EvaluationDetailsViewModel
            {
                Subject = subject,
                CopiesList = new List<CompletedCopyViewModel>(),
                EvaluationData = new List<EvaluationDataModel>()
            };

            using var connection = new SqlConnection(_connectionString);

            using var copiesCommand = new SqlCommand("sp_GetEvaluatorSubjectCopies", connection);
            copiesCommand.CommandType = CommandType.StoredProcedure;
            copiesCommand.Parameters.AddWithValue("@EvaluatorId", evaluatorId);
            copiesCommand.Parameters.AddWithValue("@Subject", subject);

            await connection.OpenAsync();
            using var copiesReader = await copiesCommand.ExecuteReaderAsync();

            while (await copiesReader.ReadAsync())
            {
                var rollNumber = copiesReader["RollNumber"].ToString();
                var studentName = copiesReader["StudentName"]?.ToString() ?? "";
                var marksObtained = Convert.ToInt32(copiesReader["TotalMarks"] ?? 0);
                var totalMarks = Convert.ToDecimal(copiesReader["MaxTotalMarks"] ?? 100);
                var percentage = totalMarks > 0 ? (marksObtained / totalMarks * 100) : 0;

                var matchesSearch = string.IsNullOrEmpty(searchTerm) ||
                                   rollNumber.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                                   studentName.Contains(searchTerm, StringComparison.OrdinalIgnoreCase);

                var isCompleted = marksObtained > 0;
                var matchesStatus = statusFilter == "all" ||
                                   (statusFilter == "completed" && isCompleted) ||
                                   (statusFilter == "pending" && !isCompleted);

                if (!matchesSearch || !matchesStatus) continue;

                model.CopiesList.Add(new CompletedCopyViewModel
                {
                    Id = Convert.ToInt32(copiesReader["Id"]),
                    Subject = subject,
                    RollNumber = rollNumber,
                    StudentName = studentName,
                    TotalMarks = marksObtained,
                    MarksObtained = totalMarks,
                    Percentage = (decimal)percentage,
                    EvaluatedQuestions = Convert.ToInt32(copiesReader["EvaluatedQuestions"] ?? 0),
                    TotalQuestions = Convert.ToInt32(copiesReader["TotalQuestions"] ?? 0),
                    EvaluatedAt = Convert.ToDateTime(copiesReader["UpdatedAt"]),
                    PdfPath = copiesReader["PdfFilePath"]?.ToString()
                });
            }

            return model;
        }

        private async Task<EvaluationDetailsViewModel> GetEvaluatedCopyDetailsAsync(string subject, string rollNumber)
        {
            var model = new EvaluationDetailsViewModel
            {
                Subject = subject,
                RollNumber = rollNumber,
                EvaluationData = new List<EvaluationDataModel>(),
                BlankPages = new List<int>(), // if you have this
                                              // DO NOT initialize computed properties here — they are get-only
            };

            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            await using var command = new SqlCommand("sp_GetEvaluationDetails", connection)
            {
                CommandType = CommandType.StoredProcedure
            };
            command.Parameters.AddWithValue("@Subject", subject);
            command.Parameters.AddWithValue("@RollNumber", rollNumber);

            await using var reader = await command.ExecuteReaderAsync();

            // First result set: Summary
            if (await reader.ReadAsync())
            {
                model.StudentName = reader["StudentName"]?.ToString();
                model.TotalQuestions = reader.GetInt32("TotalQuestions"); // safe if column exists
                model.AnswerSheetUrl = "https://cc.icsi.edu/impdocs/help%20document.pdf";//reader["AnswerSheetUrl"]?.ToString() ?? "";
                model.UpdatedAt = reader.GetDateTime("UpdatedAt"); // helper below
                model.SubmittedAt = reader.GetDateTime("SubmittedAt");
                model.EvaluatorId = reader["EvaluatorId"]?.ToString();
            }

            // Second result set: Evaluation details (marks, blank pages, etc.)
            if (await reader.NextResultAsync())
            {
                while (await reader.ReadAsync())
                {
                    var evaluationType = reader["EvaluationType"]?.ToString() ?? "mark";

                    var data = new EvaluationDataModel
                    {
                        Id = reader.GetInt32("Id"),
                        QuestionNumber = reader.GetInt32("QuestionNumber"),
                        Type = evaluationType,
                        Marks = reader.GetDecimal("Marks"),
                        Coordinates = new CoordinatesModel
                        {
                            X = reader.GetDecimal("CoordinateX"),
                            Y = reader.GetDecimal("CoordinateY"),
                            PageNumber = reader.GetInt32("PageNumber")
                        },
                        Comments = reader["Comments"]?.ToString(),
                        Timestamp = reader.GetDateTime("CreatedAt")
                    };

                    model.EvaluationData.Add(data);

                    // Collect blank pages
                    if (evaluationType == "blank_page" && data.Coordinates?.PageNumber > 0)
                    {
                        model.BlankPages.Add(data.Coordinates.PageNumber);
                    }
                }
            }

            // Now all data is loaded → computed properties will auto-calculate
            // No need to assign TotalMarks, QuestionMarks, etc. — they are computed!

            return model;
        }



        private async Task<string> GetEvaluatedPdfPathAsync(string subject, string rollNumber)
        {
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand(
                "SELECT PdfPath FROM UploadedDocuments WHERE Subject = @Subject AND RollNumber = @RollNumber ORDER BY CreatedAt DESC",
                connection);
            command.Parameters.AddWithValue("@Subject", subject);
            command.Parameters.AddWithValue("@RollNumber", rollNumber);

            await connection.OpenAsync();
            var result = await command.ExecuteScalarAsync();
            return result?.ToString() ?? "";
        }

        private async Task<RandomStudentViewModel> GetRandomStudentForEvaluationAsync(string evaluatorId, string subject)
        {
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("sp_GetRandomStudentForEvaluation", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Subject", subject);
            command.Parameters.AddWithValue("@EvaluatorId", evaluatorId);

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return new RandomStudentViewModel
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    RollNumber = reader["RollNumber"].ToString(),
                    StudentName = reader["StudentName"]?.ToString(),
                    Class = reader["Class"]?.ToString(),
                    Section = reader["Section"]?.ToString(),
                    Subject = reader["Subject"].ToString(),
                    PdfFilePath = reader["PdfFilePath"]?.ToString(),
                    CreatedAt = Convert.ToDateTime(reader["CreatedAt"]),
                    IsEvaluated = Convert.ToBoolean(reader["IsEvaluated"])
                };
            }

            return null;
        }
    }
}
