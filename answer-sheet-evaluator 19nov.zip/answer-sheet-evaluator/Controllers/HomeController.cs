using AnswerSheetEvaluator.AppData; 
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc; 
using Microsoft.IdentityModel.Tokens; 
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;

namespace AnswerSheetEvaluator.Controllers
{
    [AllowAnonymous]
    public class HomeController(IConfiguration _configuration,DataLayer dataLayer) : Controller
    {
        private readonly IConfiguration configuration = _configuration;
        private readonly DataLayer _dataLayer = dataLayer;


        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> LoadPaper(string subject, string rollNumber)
        {
            if (string.IsNullOrEmpty(subject) || string.IsNullOrEmpty(rollNumber))
            {
                TempData["Error"] = "Please select a subject and enter roll number";
                return RedirectToAction("Index");
            }
             
            await _dataLayer.EnsureEvaluationDataExists(subject, rollNumber);

            return RedirectToAction("Evaluate", "Evaluation", new { subject, rollNumber });
        }


        [HttpPost]
        [AllowAnonymous]
        public IActionResult LoginVerify([FromBody] JsonElement json)
        {
            if (!json.TryGetProperty("username", out JsonElement usernameElement) ||
                !json.TryGetProperty("password", out JsonElement passwordElement))
            {
                return BadRequest(new { message = "Username or password is missing." });
            }

            string username = usernameElement.GetString();
            string password = passwordElement.GetString();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return BadRequest(new { message = "Username or password cannot be empty." });
            }

            // Placeholder for authentication logic
            return Ok(new { message = "Login successful", username = username });
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> LoginValidate([FromBody] JsonElement json)
        {
            if (json.TryGetProperty("username", out JsonElement UserIdValue) &&
                json.TryGetProperty("password", out JsonElement PasswordValue) )
            {
                string? UserId1 = UserIdValue.GetString();
                string? Password = PasswordValue.GetString();
                string? IpAddress = "192.168.1.1";//IpAddressValue.GetString();

                if (!string.IsNullOrEmpty(UserId1) && !string.IsNullOrEmpty(Password))
                {
                    var userData = _dataLayer.LoginValidate(UserId1, Password, IpAddress);
                    if (userData != null && userData.Tables.Count > 0 && userData.Tables[0].Rows.Count > 0)
                    {
                        var row = userData.Tables[0].Rows[0];
                        string? role = row.Table.Columns.Contains("UserRole") && row["UserRole"] != DBNull.Value
                            ? row["UserRole"]?.ToString().ToUpper()
                            : null;
                        string UserId0 = row["EvaluatorId"].ToString();
                        string UserName = row["UserName"].ToString();

                        if (string.IsNullOrEmpty(role))
                        {
                            return BadRequest(new { success = false, message = "Role not found or invalid" });
                        }

                        var claims = new List<Claim>
                            {
                                new(ClaimTypes.Name, UserId1),
                                new(ClaimTypes.Role, role),
                                new Claim("UserId", UserId0),                
                                new Claim("UserName", UserName)
                            };

                        var claimsIdentity = new ClaimsIdentity(
                            claims, CookieAuthenticationDefaults.AuthenticationScheme);

                        var authProperties = new AuthenticationProperties
                        {
                            IsPersistent = true,
                            ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(180)
                        };

                        await HttpContext.SignInAsync(
                            CookieAuthenticationDefaults.AuthenticationScheme,
                            new ClaimsPrincipal(claimsIdentity),
                            authProperties);

                        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
                        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                        var token = new JwtSecurityToken(
                            issuer: configuration["Jwt:Issuer"],
                            audience: configuration["Jwt:Audience"],
                            claims: claims,
                            expires: DateTime.Now.AddMinutes(180),
                            signingCredentials: creds);

                        var jwtToken = new JwtSecurityTokenHandler().WriteToken(token);
                         
                        string? returnUrl = HttpContext.Request.Query["ReturnUrl"].ToString();
                        if (string.IsNullOrEmpty(returnUrl) || !Url.IsLocalUrl(returnUrl))
                        {
                            returnUrl = role switch
                            {
                                "ADMIN" => Url.Action("Index", "Admin"),
                                "EVALUATOR" => Url.Action("Dashboard", "Evaluator"),
                                _ => Url.Action("Login", "Home")
                            };
                        }

                        return Json(new { success = true, redirectUrl = returnUrl, token = jwtToken });
                    }
                }
            }

            return BadRequest(new { success = false, message = "Invalid login attempt" });
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Home");
        }
    }
}
