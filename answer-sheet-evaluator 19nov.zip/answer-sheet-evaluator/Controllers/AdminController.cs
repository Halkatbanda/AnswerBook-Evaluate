using AnswerSheetEvaluator.Models;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace AnswerSheetEvaluator.Controllers
{
    //[Authorize(Policy = "AdminPolicy")]
    [Authorize(Roles = "ADMIN")]
    public class AdminController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string? _connectionString;

        public AdminController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IActionResult> Index()
        {
            var model = new AdminDashboardViewModel
            {
                Evaluations = await GetAllEvaluationsAsync(),
                Statistics = await GetStatisticsAsync()
            };
            return View(model);
        }

        public async Task<IActionResult> ViewEvaluation(string subject, string rollNumber)
        {
            var model = await GetEvaluationDetailsAsync(subject, rollNumber);
            return View(model);
        }

        public async Task<IActionResult> DownloadEvaluatedPDF(string subject, string rollNumber)
        {
            try
            {
                var evaluationDetails = await GetEvaluationDetailsInternalAsync(subject, rollNumber);
                var originalPdfPath = await GetOriginalPdfPathAsync(subject, rollNumber);
                var evaluatedPdfBytes = await CreateEvaluatedPDFAsync(originalPdfPath, evaluationDetails);

                var fileName = $"{subject}_{rollNumber}_evaluated.pdf";
                return File(evaluatedPdfBytes, "application/pdf", fileName);
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error downloading PDF: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteEvaluation(string subject, string rollNumber)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                using var command = new SqlCommand("sp_DeleteEvaluation", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Subject", subject);
                command.Parameters.AddWithValue("@RollNumber", rollNumber);

                await connection.OpenAsync();
                await command.ExecuteNonQueryAsync();

                TempData["Success"] = "Evaluation deleted successfully";
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error deleting evaluation: {ex.Message}";
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> GetEvaluationDetails(string subject, string rollNumber)
        {
            try
            {
                var details = await GetEvaluationDetailsInternalAsync(subject, rollNumber);
                return Json(new { success = true, data = details });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        private async Task<List<EvaluationListItemViewModel>> GetAllEvaluationsAsync()
        {
            var evaluations = new List<EvaluationListItemViewModel>();

            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("sp_GetAllEvaluations", connection);
            command.CommandType = CommandType.StoredProcedure;

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                evaluations.Add(new EvaluationListItemViewModel
                {
                    Subject = reader["Subject"].ToString(),
                    RollNumber = reader["RollNumber"].ToString(),
                    StudentName = reader["StudentName"]?.ToString(),
                    TotalQuestions = Convert.ToInt32(reader["TotalQuestions"]),
                    EvaluatedQuestions = Convert.ToInt32(reader["EvaluatedQuestions"]),
                    TotalMarks = Convert.ToDecimal(reader["TotalMarks"]),
                    IsCompleted = Convert.ToBoolean(reader["IsCompleted"]),
                    SubmittedAt = reader["SubmittedAt"] as DateTime?,
                    AnswerSheetUrl = reader["AnswerSheetUrl"]?.ToString(),
                    CreatedAt = Convert.ToDateTime(reader["CreatedAt"])
                });
            }

            return evaluations;
        }

        private async Task<AdminStatisticsViewModel> GetStatisticsAsync()
        {
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("sp_GetAdminStatistics", connection);
            command.CommandType = CommandType.StoredProcedure;

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();

            var stats = new AdminStatisticsViewModel();

            // Read overall statistics
            if (await reader.ReadAsync())
            {
                stats.TotalEvaluations = Convert.ToInt32(reader["TotalEvaluations"]);
                stats.CompletedEvaluations = Convert.ToInt32(reader["CompletedEvaluations"]);
                stats.PendingEvaluations = Convert.ToInt32(reader["PendingEvaluations"]);
                stats.AverageMarks = Convert.ToDouble(reader["AverageMarks"]);
                stats.NewEvaluationsThisWeek = Convert.ToInt32(reader["NewEvaluationsThisWeek"]);
            }

            // Read subject statistics
            if (await reader.NextResultAsync())
            {
                stats.SubjectStats = new List<SubjectStatisticsViewModel>();
                while (await reader.ReadAsync())
                {
                    stats.SubjectStats.Add(new SubjectStatisticsViewModel
                    {
                        Subject = reader["Subject"].ToString(),
                        TotalEvaluations = Convert.ToInt32(reader["TotalEvaluations"]),
                        CompletedEvaluations = Convert.ToInt32(reader["CompletedEvaluations"]),
                        AverageMarks = Convert.ToDouble(reader["AverageMarks"]),
                        HighestMarks = Convert.ToDecimal(reader["HighestMarks"]),
                        CompletionPercentage = Convert.ToDouble(reader["CompletionPercentage"])
                    });
                }
            }

            // Read recent activity
            if (await reader.NextResultAsync())
            {
                stats.RecentActivity = new List<RecentActivityViewModel>();
                while (await reader.ReadAsync())
                {
                    stats.RecentActivity.Add(new RecentActivityViewModel
                    {
                        Action = reader["Action"].ToString(),
                        Subject = reader["Subject"].ToString(),
                        RollNumber = reader["RollNumber"].ToString(),
                        Status = reader["Status"].ToString(),
                        Timestamp = Convert.ToDateTime(reader["Timestamp"])
                    });
                }
            }

            return stats;
        }

        private async Task<EvaluationDetailsViewModel> GetEvaluationDetailsAsync(string subject, string rollNumber)
        {
            var model = new EvaluationDetailsViewModel
            {
                Subject = subject,
                RollNumber = rollNumber,
                EvaluationData = new List<EvaluationDataModel>(),
                BlankPages = new List<int>()
            };

            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("sp_GetEvaluationDetails", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Subject", subject);
            command.Parameters.AddWithValue("@RollNumber", rollNumber);

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                if (reader["EvaluationType"].ToString() == "BlankPage")
                {
                    model.BlankPages.Add(Convert.ToInt32(reader["PageNumber"]));
                }
                else
                {
                    model.EvaluationData.Add(new EvaluationDataModel
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        QuestionNumber = Convert.ToInt32(reader["QuestionNumber"]),
                        Type = reader["EvaluationType"].ToString(),
                        Marks = Convert.ToDecimal(reader["Marks"]),
                        Coordinates = new CoordinatesModel
                        {
                            X = Convert.ToDecimal(reader["CoordinateX"]),
                            Y = Convert.ToDecimal(reader["CoordinateY"]),
                            PageNumber = Convert.ToInt32(reader["PageNumber"])
                        },
                        Timestamp = Convert.ToDateTime(reader["CreatedAt"])
                    });
                }
            }

            return model;
        }

        private async Task<List<EvaluationDataModel>> GetEvaluationDetailsInternalAsync(string subject, string rollNumber)
        {
            var evaluationData = new List<EvaluationDataModel>();

            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("sp_GetEvaluationDetails", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Subject", subject);
            command.Parameters.AddWithValue("@RollNumber", rollNumber);

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                if (reader["EvaluationType"].ToString() != "BlankPage")
                {
                    evaluationData.Add(new EvaluationDataModel
                    {
                        QuestionNumber = Convert.ToInt32(reader["QuestionNumber"]),
                        Type = reader["EvaluationType"].ToString(),
                        Marks = Convert.ToDecimal(reader["Marks"]),
                        Coordinates = new CoordinatesModel
                        {
                            X = Convert.ToDecimal(reader["CoordinateX"]),
                            Y = Convert.ToDecimal(reader["CoordinateY"]),
                            PageNumber = Convert.ToInt32(reader["PageNumber"])
                        }
                    });
                }
            }

            return evaluationData;
        }

        private async Task<string> GetOriginalPdfPathAsync(string subject, string rollNumber)
        {
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("SELECT AnswerSheetUrl FROM AnswerSheets WHERE Subject = @Subject AND RollNumber = @RollNumber", connection);
            command.Parameters.AddWithValue("@Subject", subject);
            command.Parameters.AddWithValue("@RollNumber", rollNumber);

            await connection.OpenAsync();
            var result = await command.ExecuteScalarAsync();
            return result?.ToString() ?? "/placeholder.pdf";
        }

        private async Task<byte[]> CreateEvaluatedPDFAsync(string originalPdfPath, List<EvaluationDataModel> evaluationData)
        {
            using var memoryStream = new MemoryStream();

            var document = new Document();
            var writer = PdfWriter.GetInstance(document, memoryStream);

            document.Open();

            // Add title
            var titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
            document.Add(new Paragraph("Evaluated Answer Sheet", titleFont));
            document.Add(new Paragraph(" "));

            // Add evaluation summary
            var normalFont = FontFactory.GetFont(FontFactory.HELVETICA, 12);
            document.Add(new Paragraph($"Total Marks: {evaluationData.Where(e => e.Type == "mark").Sum(e => e.Marks)}", normalFont));
            document.Add(new Paragraph($"Questions Evaluated: {evaluationData.Where(e => e.Type == "mark").Select(e => e.QuestionNumber).Distinct().Count()}", normalFont));
            document.Add(new Paragraph(" "));

            // Add question-wise marks
            var questionMarks = evaluationData
                .Where(e => e.Type == "mark")
                .GroupBy(e => e.QuestionNumber)
                .ToDictionary(g => g.Key, g => g.Sum(e => e.Marks));

            document.Add(new Paragraph("Question-wise Marks:", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14)));

            foreach (var qm in questionMarks.OrderBy(x => x.Key))
            {
                document.Add(new Paragraph($"Question {qm.Key}: {qm.Value} marks", normalFont));
            }

            document.Close();

            return memoryStream.ToArray();
        }
    }
}
