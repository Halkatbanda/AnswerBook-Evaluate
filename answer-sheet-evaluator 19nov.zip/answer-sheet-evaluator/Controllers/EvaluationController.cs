using AnswerSheetEvaluator.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Text.Json;

namespace AnswerSheetEvaluator.Controllers
{
    public class EvaluationController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public EvaluationController(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public IActionResult Evaluate(string subject, string rollNumber)
        {
            if (string.IsNullOrEmpty(subject) || string.IsNullOrEmpty(rollNumber))
            {
                TempData["Error"] = "Subject and Roll Number are required.";
                return RedirectToAction("Index", "Home");
            }

            var model = new EvaluationViewModel
            {
                Subject = subject,
                RollNumber = rollNumber,
                TotalQuestions = GetTotalQuestions(subject),
                PdfUrl = GetPdfUrl(subject, rollNumber)
            };

            return View(model);
        }

        //[HttpPost]
        //public async Task<IActionResult> SaveEvaluation([FromBody] SaveEvaluationRequest request)
        //{
        //    try
        //    {
        //        string Subject = request.Subject;
        //        string rollnumber = request.RollNumber;
        //        using var connection = new SqlConnection(_connectionString);
        //        await connection.OpenAsync();

        //        using var transaction = connection.BeginTransaction();

        //        try
        //        {
        //            // Delete existing evaluation data
        //            using var deleteCommand = new SqlCommand("sp_DeleteEvaluationData", connection, transaction);
        //            deleteCommand.CommandType = CommandType.StoredProcedure;
        //            deleteCommand.Parameters.AddWithValue("@Subject", request.Subject);
        //            deleteCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber);
        //            await deleteCommand.ExecuteNonQueryAsync();

        //            // Insert new evaluation data
        //            foreach (var item in request.EvaluationData)
        //            {
        //                using var insertCommand = new SqlCommand("sp_InsertEvaluationData", connection, transaction);
        //                insertCommand.CommandType = CommandType.StoredProcedure;
        //                insertCommand.Parameters.AddWithValue("@Subject", request.Subject);
        //                insertCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber);
        //                insertCommand.Parameters.AddWithValue("@QuestionNumber", item.QuestionNumber);
        //                insertCommand.Parameters.AddWithValue("@EvaluationType", item.Type);
        //                insertCommand.Parameters.AddWithValue("@Marks", item.Marks);
        //                insertCommand.Parameters.AddWithValue("@Coordinates",
        //                    item.Coordinates != null ? JsonConvert.SerializeObject(item.Coordinates) : null);
        //                insertCommand.Parameters.AddWithValue("@PageNumber",
        //                    item.Coordinates?.PageNumber ?? (object)DBNull.Value);
        //                await insertCommand.ExecuteNonQueryAsync();
        //            }

        //            foreach (var pageNumber in request.BlankPages)
        //            {
        //                using var insertCommand = new SqlCommand("sp_InsertEvaluationData", connection, transaction);
        //                insertCommand.CommandType = CommandType.StoredProcedure;
        //                insertCommand.Parameters.AddWithValue("@Subject", request.Subject);
        //                insertCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber);
        //                insertCommand.Parameters.AddWithValue("@QuestionNumber", DBNull.Value);
        //                insertCommand.Parameters.AddWithValue("@EvaluationType", "blank_page");
        //                insertCommand.Parameters.AddWithValue("@Marks", 0);
        //                insertCommand.Parameters.AddWithValue("@Coordinates", DBNull.Value);
        //                insertCommand.Parameters.AddWithValue("@PageNumber", pageNumber);
        //                await insertCommand.ExecuteNonQueryAsync();
        //            }

        //            // Update evaluation summary
        //            var totalMarks = request.EvaluationData.Where(x => x.Type == "mark").Sum(x => x.Marks);
        //            var evaluatedQuestions = request.EvaluationData.Where(x => x.Type == "mark")
        //                .Select(x => x.QuestionNumber).Distinct().Count();

        //            using var summaryCommand = new SqlCommand("sp_UpdateEvaluationSummary", connection, transaction);
        //            summaryCommand.CommandType = CommandType.StoredProcedure;
        //            summaryCommand.Parameters.AddWithValue("@Subject", request.Subject);
        //            summaryCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber);
        //            summaryCommand.Parameters.AddWithValue("@TotalMarks", totalMarks);
        //            summaryCommand.Parameters.AddWithValue("@TotalQuestions", request.TotalQuestions);
        //            summaryCommand.Parameters.AddWithValue("@EvaluatedQuestions", evaluatedQuestions);
        //            summaryCommand.Parameters.AddWithValue("@BlankPages", request.BlankPages.Count);
        //            summaryCommand.Parameters.AddWithValue("@SubmittedAt", request.SubmittedAt);
        //            await summaryCommand.ExecuteNonQueryAsync();

        //            transaction.Commit();

        //            return Json(new
        //            {
        //                success = true,
        //                message = "Evaluation saved successfully"
        //            });
        //        }
        //        catch
        //        {
        //            transaction.Rollback();
        //            throw;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json(new { success = false, message = $"Error: {ex.Message}" });
        //    }
        //}



        [HttpPost]
        public async Task<IActionResult> SaveEvaluation([FromBody] JsonElement request)
        {
            try
            {
                string subject = request.GetProperty("Subject").GetString();
                string rollNumber = request.GetProperty("RollNumber").GetRawText(); // works for int or string
                int totalQuestions = request.GetProperty("TotalQuestions").GetInt32();
                DateTime submittedAt = request.GetProperty("SubmittedAt").GetDateTime();

                using var connection = new SqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = connection.BeginTransaction();

                try
                {
                    // Delete existing evaluation data
                    using var deleteCommand = new SqlCommand("sp_DeleteEvaluationData", connection, transaction);
                    deleteCommand.CommandType = CommandType.StoredProcedure;
                    deleteCommand.Parameters.AddWithValue("@Subject", subject);
                    deleteCommand.Parameters.AddWithValue("@RollNumber", rollNumber);
                    await deleteCommand.ExecuteNonQueryAsync();

                    // Insert new evaluation data
                    foreach (var item in request.GetProperty("EvaluationData").EnumerateArray())
                    {
                        using var insertCommand = new SqlCommand("sp_InsertEvaluationData", connection, transaction);
                        insertCommand.CommandType = CommandType.StoredProcedure;
                        insertCommand.Parameters.AddWithValue("@Subject", subject);
                        insertCommand.Parameters.AddWithValue("@RollNumber", rollNumber);
                        insertCommand.Parameters.AddWithValue("@QuestionNumber", item.GetProperty("questionNumber").GetInt32());
                        insertCommand.Parameters.AddWithValue("@EvaluationType", item.GetProperty("type").GetString());
                        insertCommand.Parameters.AddWithValue("@Marks", item.GetProperty("marks").GetDecimal());

                        // Handle coordinates safely
                        if (item.TryGetProperty("coordinates", out JsonElement coords) && coords.ValueKind == JsonValueKind.Object)
                        {
                            insertCommand.Parameters.AddWithValue("@Coordinates", System.Text.Json.JsonSerializer.Serialize(coords));
                            if (coords.TryGetProperty("pageNumber", out JsonElement pageNum) && pageNum.ValueKind == JsonValueKind.Number)
                                insertCommand.Parameters.AddWithValue("@PageNumber", pageNum.GetInt32());
                            else
                                insertCommand.Parameters.AddWithValue("@PageNumber", DBNull.Value);
                        }
                        else
                        {
                            insertCommand.Parameters.AddWithValue("@Coordinates", DBNull.Value);
                            insertCommand.Parameters.AddWithValue("@PageNumber", DBNull.Value);
                        }

                        await insertCommand.ExecuteNonQueryAsync();
                    }

                    // Insert blank pages
                    foreach (var pageNumber in request.GetProperty("BlankPages").EnumerateArray())
                    {
                        using var insertCommand = new SqlCommand("sp_InsertEvaluationData", connection, transaction);
                        insertCommand.CommandType = CommandType.StoredProcedure;
                        insertCommand.Parameters.AddWithValue("@Subject", subject);
                        insertCommand.Parameters.AddWithValue("@RollNumber", rollNumber);
                        insertCommand.Parameters.AddWithValue("@QuestionNumber", DBNull.Value);
                        insertCommand.Parameters.AddWithValue("@EvaluationType", "blank_page");
                        insertCommand.Parameters.AddWithValue("@Marks", 0);
                        insertCommand.Parameters.AddWithValue("@Coordinates", DBNull.Value);
                        insertCommand.Parameters.AddWithValue("@PageNumber", pageNumber.GetInt32());
                        await insertCommand.ExecuteNonQueryAsync();
                    }

                    // Update evaluation summary
                    var marksArray = request.GetProperty("EvaluationData").EnumerateArray()
                        .Where(x => x.GetProperty("type").GetString() == "mark");

                    var totalMarks = marksArray.Sum(x => x.GetProperty("marks").GetDecimal());
                    var evaluatedQuestions = marksArray
                        .Select(x => x.GetProperty("questionNumber").GetInt32())
                        .Distinct()
                        .Count();

                    using var summaryCommand = new SqlCommand("sp_UpdateEvaluationSummary", connection, transaction);
                    summaryCommand.CommandType = CommandType.StoredProcedure;
                    summaryCommand.Parameters.AddWithValue("@Subject", subject);
                    summaryCommand.Parameters.AddWithValue("@RollNumber", rollNumber);
                    summaryCommand.Parameters.AddWithValue("@TotalMarks", totalMarks);
                    summaryCommand.Parameters.AddWithValue("@TotalQuestions", totalQuestions);
                    summaryCommand.Parameters.AddWithValue("@EvaluatedQuestions", evaluatedQuestions);
                    summaryCommand.Parameters.AddWithValue("@BlankPages", request.GetProperty("BlankPages").GetArrayLength());
                    summaryCommand.Parameters.AddWithValue("@SubmittedAt", submittedAt);
                    await summaryCommand.ExecuteNonQueryAsync();

                    transaction.Commit();
                    return Ok(new { success = true, message = "Evaluation saved successfully" });
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return BadRequest(new { success = false, message = $"Error: {ex.Message}" });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Error: {ex.Message}" });
            }
        }



        [HttpPost]
        public async Task<IActionResult> SubmitEvaluation([FromBody] SubmitEvaluationRequest request)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                await connection.OpenAsync();

                using var transaction = connection.BeginTransaction();

                try
                {
                    var evaluatorId = User?.Identity?.Name ?? "EVALUATOR_SYSTEM"; // Get authenticated user ID

                    using var deleteCommand = new SqlCommand(
                        "DELETE FROM Evaluations WHERE Subject = @Subject AND RollNumber = @RollNumber",
                        connection, transaction);
                    deleteCommand.Parameters.AddWithValue("@Subject", request.Subject ?? "");
                    deleteCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber ?? "");
                    await deleteCommand.ExecuteNonQueryAsync();

                    foreach (var item in request.EvaluationData)
                    {
                        using var insertCommand = new SqlCommand(
                            @"INSERT INTO Evaluations (Subject, RollNumber, QuestionNumber, EvaluationType, Marks, CoordinateX, CoordinateY, PageNumber, Comments, EvaluatorId, CreatedAt)
                              VALUES (@Subject, @RollNumber, @QuestionNumber, @EvaluationType, @Marks, @CoordinateX, @CoordinateY, @PageNumber, @Comments, @EvaluatorId, @CreatedAt)",
                            connection, transaction);

                        insertCommand.Parameters.AddWithValue("@Subject", request.Subject ?? "");
                        insertCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber ?? "");
                        insertCommand.Parameters.AddWithValue("@QuestionNumber", item?.QuestionNumber ?? (object)DBNull.Value);
                        insertCommand.Parameters.AddWithValue("@EvaluationType", item?.Type ?? "mark");
                        insertCommand.Parameters.AddWithValue("@Marks", item?.Marks ?? 0);
                        insertCommand.Parameters.AddWithValue("@CoordinateX", item?.Coordinates?.X ?? (object)DBNull.Value);
                        insertCommand.Parameters.AddWithValue("@CoordinateY", item?.Coordinates?.Y ?? (object)DBNull.Value);
                        insertCommand.Parameters.AddWithValue("@PageNumber", item?.Coordinates?.PageNumber ?? (object)DBNull.Value);
                        insertCommand.Parameters.AddWithValue("@Comments", item?.Comments ?? (object)DBNull.Value);
                        insertCommand.Parameters.AddWithValue("@EvaluatorId", evaluatorId);
                        insertCommand.Parameters.AddWithValue("@CreatedAt", DateTime.UtcNow);

                        await insertCommand.ExecuteNonQueryAsync();
                    }

                    if (request.BlankPages != null && request.BlankPages.Count > 0)
                    {
                        foreach (var pageNumber in request.BlankPages)
                        {
                            using var blankCommand = new SqlCommand(
                                @"INSERT INTO Evaluations (Subject, RollNumber, QuestionNumber, EvaluationType, Marks, PageNumber, EvaluatorId, CreatedAt)
                                  VALUES (@Subject, @RollNumber, NULL, @EvaluationType, 0, @PageNumber, @EvaluatorId, @CreatedAt)",
                                connection, transaction);

                            blankCommand.Parameters.AddWithValue("@Subject", request.Subject ?? "");
                            blankCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber ?? "");
                            blankCommand.Parameters.AddWithValue("@EvaluationType", "BlankPage");
                            blankCommand.Parameters.AddWithValue("@PageNumber", pageNumber);
                            blankCommand.Parameters.AddWithValue("@EvaluatorId", evaluatorId);
                            blankCommand.Parameters.AddWithValue("@CreatedAt", DateTime.UtcNow);

                            await blankCommand.ExecuteNonQueryAsync();
                        }
                    }

                    var totalMarks = request.EvaluationData
                        .Where(x => x != null && x.Type == "mark")
                        .Sum(x => x.Marks ?? 0);

                    var evaluatedQuestions = request.EvaluationData
                        .Where(x => x != null && x.Type == "mark" && x.QuestionNumber.HasValue)
                        .Select(x => x.QuestionNumber)
                        .Distinct()
                        .Count();

                    var completionPercentage = request.TotalQuestions > 0
                        ? Math.Round((evaluatedQuestions * 100.0m) / request.TotalQuestions, 2)
                        : 0;

                    using var checkCommand = new SqlCommand(
                        "SELECT COUNT(*) FROM EvaluationSummary WHERE Subject = @Subject AND RollNumber = @RollNumber",
                        connection, transaction);
                    checkCommand.Parameters.AddWithValue("@Subject", request.Subject ?? "");
                    checkCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber ?? "");

                    var existingCount = (int)(await checkCommand.ExecuteScalarAsync() ?? 0);

                    if (existingCount > 0)
                    {
                        using var updateCommand = new SqlCommand(
                            @"UPDATE EvaluationSummary 
                              SET TotalMarks = @TotalMarks, 
                                  EvaluatedQuestions = @EvaluatedQuestions,
                                  CompletionPercentage = @CompletionPercentage,
                                  IsCompleted = @IsCompleted,
                                  SubmittedAt = @SubmittedAt,
                                  EvaluatorId = @EvaluatorId,
                                  UpdatedAt = GETDATE()
                              WHERE Subject = @Subject AND RollNumber = @RollNumber",
                            connection, transaction);

                        updateCommand.Parameters.AddWithValue("@TotalMarks", totalMarks);
                        updateCommand.Parameters.AddWithValue("@EvaluatedQuestions", evaluatedQuestions);
                        updateCommand.Parameters.AddWithValue("@CompletionPercentage", completionPercentage);
                        updateCommand.Parameters.AddWithValue("@IsCompleted", evaluatedQuestions == request.TotalQuestions ? 1 : 0);
                        updateCommand.Parameters.AddWithValue("@SubmittedAt", DateTime.UtcNow);
                        updateCommand.Parameters.AddWithValue("@EvaluatorId", evaluatorId);
                        updateCommand.Parameters.AddWithValue("@Subject", request.Subject ?? "");
                        updateCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber ?? "");

                        await updateCommand.ExecuteNonQueryAsync();
                    }
                    else
                    {
                        using var insertSummaryCommand = new SqlCommand(
                            @"INSERT INTO EvaluationSummary (Subject, RollNumber, TotalQuestions, TotalMarks, EvaluatedQuestions, CompletionPercentage, IsCompleted, SubmittedAt, EvaluatorId, CreatedAt)
                              VALUES (@Subject, @RollNumber, @TotalQuestions, @TotalMarks, @EvaluatedQuestions, @CompletionPercentage, @IsCompleted, @SubmittedAt, @EvaluatorId, @CreatedAt)",
                            connection, transaction);

                        insertSummaryCommand.Parameters.AddWithValue("@Subject", request.Subject ?? "");
                        insertSummaryCommand.Parameters.AddWithValue("@RollNumber", request.RollNumber ?? "");
                        insertSummaryCommand.Parameters.AddWithValue("@TotalQuestions", request.TotalQuestions);
                        insertSummaryCommand.Parameters.AddWithValue("@TotalMarks", totalMarks);
                        insertSummaryCommand.Parameters.AddWithValue("@EvaluatedQuestions", evaluatedQuestions);
                        insertSummaryCommand.Parameters.AddWithValue("@CompletionPercentage", completionPercentage);
                        insertSummaryCommand.Parameters.AddWithValue("@IsCompleted", evaluatedQuestions == request.TotalQuestions ? 1 : 0);
                        insertSummaryCommand.Parameters.AddWithValue("@SubmittedAt", DateTime.UtcNow);
                        insertSummaryCommand.Parameters.AddWithValue("@EvaluatorId", evaluatorId);
                        insertSummaryCommand.Parameters.AddWithValue("@CreatedAt", DateTime.UtcNow);

                        await insertSummaryCommand.ExecuteNonQueryAsync();
                    }

                    using var updateAssignmentCommand = new SqlCommand(
                        @"UPDATE EvaluatorAssignments 
                          SET CompletedCopies = CompletedCopies + 1
                          WHERE EvaluatorId = @EvaluatorId AND Subject = @Subject",
                        connection, transaction);

                    updateAssignmentCommand.Parameters.AddWithValue("@EvaluatorId", evaluatorId);
                    updateAssignmentCommand.Parameters.AddWithValue("@Subject", request.Subject ?? "");

                    await updateAssignmentCommand.ExecuteNonQueryAsync();

                    transaction.Commit();

                    return Json(new
                    {
                        success = true,
                        message = "Evaluation submitted successfully",
                        data = new
                        {
                            totalMarks = totalMarks,
                            evaluatedQuestions = evaluatedQuestions,
                            completionPercentage = completionPercentage,
                            isCompleted = evaluatedQuestions == request.TotalQuestions
                        }
                    });
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Error submitting evaluation: {ex.Message}" });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetEvaluationData(string subject, string rollNumber)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                using var command = new SqlCommand("sp_GetEvaluationData", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Subject", subject);
                command.Parameters.AddWithValue("@RollNumber", rollNumber);

                await connection.OpenAsync();
                using var reader = await command.ExecuteReaderAsync();

                var evaluationData = new List<object>();
                var blankPages = new List<int>();

                while (await reader.ReadAsync())
                {
                    if (reader["EvaluationType"].ToString() == "blank_page")
                    {
                        blankPages.Add(Convert.ToInt32(reader["PageNumber"]));
                    }
                    else
                    {
                        evaluationData.Add(new
                        {
                            id = reader["Id"],
                            questionNumber = Convert.ToInt32(reader["QuestionNumber"]),
                            type = reader["EvaluationType"].ToString(),
                            marks = Convert.ToDecimal(reader["Marks"]),
                            coordinates = !reader.IsDBNull("Coordinates")
                                ? JsonConvert.DeserializeObject(reader["Coordinates"].ToString())
                                : null,
                            timestamp = reader["CreatedAt"].ToString()
                        });
                    }
                }

                return Json(new { evaluationData, blankPages });
            }
            catch (Exception ex)
            {
                return Json(new { error = ex.Message });
            }
        }

        private int GetTotalQuestions(string subject)
        {
            var questionCounts = new Dictionary<string, int>
            {
                { "Mathematics", 10 },
                { "Physics", 8 },
                { "Chemistry", 9 },
                { "Biology", 12 },
                { "English", 15 }
            };

            return questionCounts.ContainsKey(subject) ? questionCounts[subject] : 10;
        }

        private string GetPdfUrl(string subject, string rollNumber)
        {
            return "";
        }
    }

    public class SaveEvaluationRequest
    {
        public string? Subject { get; set; }
        public string? RollNumber { get; set; }
        public List<EvaluationDataItem> EvaluationData { get; set; }
        public List<int> BlankPages { get; set; }
        public int TotalQuestions { get; set; }
        public DateTime SubmittedAt { get; set; }
    }

    public class EvaluationDataItem
    {
        public int QuestionNumber { get; set; }
        public string Type { get; set; }
        public decimal Marks { get; set; }
        public CoordinateData Coordinates { get; set; }
    }

    public class CoordinateData
    {
        public decimal X { get; set; }
        public decimal Y { get; set; }
        public int PageNumber { get; set; }
    }

    public class SubmitEvaluationRequest
    {
        public string Subject { get; set; }
        public string RollNumber { get; set; }
        public List<EvaluationItem> EvaluationData { get; set; }
        public List<int> BlankPages { get; set; }
        public int TotalQuestions { get; set; }
    }

    public class EvaluationItem
    {
        public int? QuestionNumber { get; set; }
        public string Type { get; set; }
        public decimal? Marks { get; set; }
        public CoordinateInfo Coordinates { get; set; }
        public string Comments { get; set; }
    }

    public class CoordinateInfo
    {
        public decimal X { get; set; }
        public decimal Y { get; set; }
        public int PageNumber { get; set; }
    }
}
