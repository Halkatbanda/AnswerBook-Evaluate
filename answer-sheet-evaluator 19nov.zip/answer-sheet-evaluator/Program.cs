using AnswerSheetEvaluator.AppData;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<DataLayer>();

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(180);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});


// Configure Authentication
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = CookieAuthenticationDefaults.AuthenticationScheme;
})
.AddCookie(options =>
{
    options.AccessDeniedPath = new PathString("/Home/Login");
    options.LoginPath = new PathString("/Home/Login");
    options.LogoutPath = new PathString("/Home/Login");
    options.ExpireTimeSpan = TimeSpan.FromMinutes(180);
    options.SlidingExpiration = true;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])),
        ClockSkew = TimeSpan.Zero
    };
});



// Add authorization policy to require authenticated users globally
//builder.Services.AddAuthorization(options =>
//{
//    options.AddPolicy("AdminPolicy", policy => policy.RequireRole("ADMIN", "Admin", "admin"));
//    options.FallbackPolicy = new AuthorizationPolicyBuilder(
//        CookieAuthenticationDefaults.AuthenticationScheme,
//        JwtBearerDefaults.AuthenticationScheme)
//        .RequireAuthenticatedUser()
//        .Build();
//});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();

// Serve static files with conditional authentication
app.UseStaticFiles(new StaticFileOptions
{
    OnPrepareResponse = ctx =>
    {
        // Allow public access to essential files for the login page
        var allowedFiles = new[]
        {
            "jquery.min.js",
            "jquery-3.6.0.min.js",
            "bootstrap.min.css",
            "bootstrap.bundle.min.js",
            "jquery.validate.min.js",
            "sweetalert2.all.min.js",
            "dataTables.min.css",
            "dataTables.min.js",
            "site.css",
            "login.js",
            "site.js"
        };
        if (allowedFiles.Contains(ctx.File.Name, StringComparer.OrdinalIgnoreCase))
        {
            return;
        }
        if (!ctx.Context.User.Identity.IsAuthenticated)
        {
            ctx.Context.Response.Redirect("/Home/Login");
        }
    }
});

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
   pattern: "{controller=Home}/{action=Login}/{id?}");
   //pattern: "{controller=Evaluator}/{action=Dashboard}/{id?}");

app.Run();
