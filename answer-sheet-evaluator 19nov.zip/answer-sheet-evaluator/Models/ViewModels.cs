using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using System;

namespace AnswerSheetEvaluator.Models
{
    // Home Page Models
    public class HomeViewModel
    {
        public List<SubjectModel> Subjects { get; set; } = new();
        public string SelectedSubject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
    }

    public class SubjectModel
    {
        public string Value { get; set; } = string.Empty;
        public string Label { get; set; } = string.Empty;
    }

    // Evaluation Models
    public class EvaluationViewModel
    {
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string PdfUrl { get; set; } = string.Empty;
        public int TotalQuestions { get; set; } = 20;
        public List<EvaluationDataModel> ExistingEvaluationData { get; set; } = new();
        public List<int> ExistingBlankPages { get; set; } = new();
    }

    public class EvaluationSubmissionModel
    {
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public List<EvaluationDataModel> EvaluationData { get; set; } = new();
        public List<int> BlankPages { get; set; } = new();
        public int TotalQuestions { get; set; }
        public string SubmittedAt { get; set; } = string.Empty;
    }

    public class EvaluationDataModel
    {
        public int Id { get; set; }
        public int QuestionNumber { get; set; }
        public string Type { get; set; } = string.Empty; // mark, tick, cross, line, delete
        public decimal Marks { get; set; }
        public CoordinatesModel Coordinates { get; set; } = new();
        public DateTime Timestamp { get; set; }
        public string? Comments { get; set; }
    }

    public class CoordinatesModel
    {
        public decimal X { get; set; }
        public decimal Y { get; set; }
        public int PageNumber { get; set; }
    }

    // Admin Dashboard Models
    public class AdminDashboardViewModel
    {
        public List<EvaluationListItemViewModel> Evaluations { get; set; } = new();
        public AdminStatisticsViewModel Statistics { get; set; } = new();
        public string SearchTerm { get; set; } = string.Empty;
        public string SubjectFilter { get; set; } = "all";
        public string StatusFilter { get; set; } = "all";
        public List<string> AvailableSubjects { get; set; } = new();
        public PaginationModel Pagination { get; set; } = new();
    }

    public class EvaluationListItemViewModel
    {
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public int TotalQuestions { get; set; }
        public int EvaluatedQuestions { get; set; }
        public decimal TotalMarks { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? SubmittedAt { get; set; }
        public string? AnswerSheetUrl { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? EvaluatorId { get; set; }
        public decimal CompletionPercentage { get; set; }

        // Computed Properties
        public string StatusBadge => IsCompleted ? "Completed" : EvaluatedQuestions > 0 ? "Partial" : "Not Started";
        public string StatusClass => IsCompleted ? "badge-success" : EvaluatedQuestions > 0 ? "badge-warning" : "badge-secondary";
        public string FormattedSubmittedDate => SubmittedAt?.ToString("MMM dd, yyyy") ?? "Not submitted";
        public string FormattedCreatedDate => CreatedAt.ToString("MMM dd, yyyy");
    }

    public class AdminStatisticsViewModel
    {
        public int TotalEvaluations { get; set; }
        public int CompletedEvaluations { get; set; }
        public int PendingEvaluations { get; set; }
        public int InProgressEvaluations { get; set; }
        public double AverageMarks { get; set; }
        public decimal HighestMarks { get; set; }
        public decimal LowestMarks { get; set; }
        public int NewEvaluationsThisWeek { get; set; }
        public int NewEvaluationsThisMonth { get; set; }
        public double CompletionRate { get; set; }
        public List<SubjectStatisticsViewModel> SubjectStats { get; set; } = new();
        public List<RecentActivityViewModel> RecentActivity { get; set; } = new();
        public List<DailyEvaluationStatsViewModel> DailyStats { get; set; } = new();
    }

    public class SubjectStatisticsViewModel
    {
        public string Subject { get; set; } = string.Empty;
        public string SubjectName { get; set; } = string.Empty;
        public int TotalEvaluations { get; set; }
        public int CompletedEvaluations { get; set; }
        public int PendingEvaluations { get; set; }
        public double AverageMarks { get; set; }
        public decimal HighestMarks { get; set; }
        public decimal LowestMarks { get; set; }
        public double CompletionPercentage { get; set; }
        public int TotalStudents { get; set; }
    }

    public class RecentActivityViewModel
    {
        public string Action { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
        public string? EvaluatorId { get; set; }
        public decimal? Marks { get; set; }

        public string FormattedTimestamp => Timestamp.ToString("MMM dd, yyyy HH:mm");
        public string TimeAgo
        {
            get
            {
                var timeSpan = DateTime.Now - Timestamp;
                if (timeSpan.TotalMinutes < 1) return "Just now";
                if (timeSpan.TotalMinutes < 60) return $"{(int)timeSpan.TotalMinutes} minutes ago";
                if (timeSpan.TotalHours < 24) return $"{(int)timeSpan.TotalHours} hours ago";
                if (timeSpan.TotalDays < 7) return $"{(int)timeSpan.TotalDays} days ago";
                return Timestamp.ToString("MMM dd, yyyy");
            }
        }
    }

    public class DailyEvaluationStatsViewModel
    {
        public DateTime Date { get; set; }
        public int TotalEvaluations { get; set; }
        public int CompletedEvaluations { get; set; }
        public double AverageMarks { get; set; }

        public string FormattedDate => Date.ToString("MMM dd");
    }

    // Evaluation Details Models
    public class EvaluationDetailsViewModel
    {
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public string? AnswerSheetUrl { get; set; }
        public int TotalQuestions { get; set; }
        public List<EvaluationDataModel> EvaluationData { get; set; } = new();
        public List<int> BlankPages { get; set; } = new();
        public DateTime? SubmittedAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? EvaluatorId { get; set; }
        public List<CompletedCopyViewModel> CopiesList { get; set; } = new();

        // Computed Properties
        public decimal TotalMarks => EvaluationData.Where(e => e.Type == "mark").Sum(e => e.Marks);
        public int EvaluatedQuestions => EvaluationData.Where(e => e.Type == "mark").Select(e => e.QuestionNumber).Distinct().Count();
        public decimal CompletionPercentage => TotalQuestions > 0 ? Math.Round((decimal)EvaluatedQuestions / TotalQuestions * 100, 1) : 0;
        public bool IsCompleted => EvaluatedQuestions == TotalQuestions;
        public Dictionary<int, decimal> QuestionMarks => EvaluationData
            .Where(e => e.Type == "mark")
            .GroupBy(e => e.QuestionNumber)
            .ToDictionary(g => g.Key, g => g.Sum(e => e.Marks));
    }

    // Entity Models (Database Models)
    public class Student
    {
        public int Id { get; set; }
        public string RollNumber { get; set; } = string.Empty;
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class Subject
    {
        public int Id { get; set; }
        public string SubjectCode { get; set; } = string.Empty;
        public string SubjectName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class AnswerSheet
    {
        public int Id { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? AnswerSheetUrl { get; set; }
        public string? QuestionPaperUrl { get; set; }
        public int TotalQuestions { get; set; }
        public DateTime? ExamDate { get; set; }
        public DateTime UploadedAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class Evaluation
    {
        public int Id { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public int? QuestionNumber { get; set; }
        public string EvaluationType { get; set; } = string.Empty;
        public decimal Marks { get; set; }
        public decimal? CoordinateX { get; set; }
        public decimal? CoordinateY { get; set; }
        public int? PageNumber { get; set; }
        public string? Comments { get; set; }
        public string? EvaluatorId { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class EvaluationSummary
    {
        public int Id { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public int TotalQuestions { get; set; }
        public decimal TotalMarks { get; set; }
        public int EvaluatedQuestions { get; set; }
        public decimal CompletionPercentage { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? SubmittedAt { get; set; }
        public string? EvaluatorId { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    // Utility Models
    public class PaginationModel
    {
        public int CurrentPage { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public int TotalItems { get; set; }
        public int TotalPages => (int)Math.Ceiling((double)TotalItems / PageSize);
        public bool HasPreviousPage => CurrentPage > 1;
        public bool HasNextPage => CurrentPage < TotalPages;
        public int StartItem => (CurrentPage - 1) * PageSize + 1;
        public int EndItem => Math.Min(CurrentPage * PageSize, TotalItems);
    }

    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public T? Data { get; set; }
        public List<string> Errors { get; set; } = new();
    }

    public class FileUploadModel
    {
        [Required]
        public IFormFile File { get; set; } = null!;
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string FileType { get; set; } = string.Empty; // "answer_sheet" or "question_paper"
    }

    // Settings Models
    public class SystemSettingsViewModel
    {
        public int DefaultQuestionsCount { get; set; } = 20;
        public int MaxMarksPerQuestion { get; set; } = 10;
        public string PDFStoragePath { get; set; } = string.Empty;
        public List<string> AllowedFileTypes { get; set; } = new();
        public int MaxFileSizeMB { get; set; } = 50;
        public bool EnableAutoSave { get; set; } = true;
        public int AutoSaveIntervalMinutes { get; set; } = 5;
        public string DefaultPDFQuality { get; set; } = "high";
    }

    // Error Models
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
        public string ErrorMessage { get; set; } = string.Empty;
        public string? StackTrace { get; set; }
        public int StatusCode { get; set; }
    }

    // Report Models
    public class EvaluationReportViewModel
    {
        public string Subject { get; set; } = string.Empty;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public List<EvaluationReportItemViewModel> Items { get; set; } = new();
        public EvaluationReportSummaryViewModel Summary { get; set; } = new();
    }

    public class EvaluationReportItemViewModel
    {
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public int TotalQuestions { get; set; }
        public int EvaluatedQuestions { get; set; }
        public decimal TotalMarks { get; set; }
        public decimal CompletionPercentage { get; set; }
        public DateTime? SubmittedAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public Dictionary<int, decimal> QuestionMarks { get; set; } = new();
    }

    public class EvaluationReportSummaryViewModel
    {
        public int TotalEvaluations { get; set; }
        public int CompletedEvaluations { get; set; }
        public double AverageMarks { get; set; }
        public decimal HighestMarks { get; set; }
        public decimal LowestMarks { get; set; }
        public double CompletionRate { get; set; }
    }

    // Bulk Operations Models
    public class BulkEvaluationModel
    {
        public List<string> RollNumbers { get; set; } = new();
        public string Subject { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty; // "delete", "export", "reset"
    }

    public class BulkUploadModel
    {
        public IFormFile ExcelFile { get; set; } = null!;
        public string Subject { get; set; } = string.Empty;
        public bool OverwriteExisting { get; set; } = false;
    }

    // Document Upload and Image Capture Models
    public class DocumentUploadViewModel
    {
        public string Subject { get; set; } = string.Empty;
        public string Class { get; set; } = string.Empty;
        public string Section { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public List<string> CapturedImages { get; set; } = new();
        public List<SubjectModel> Subjects { get; set; } = new();
        public List<string> Classes { get; set; } = new();
        public List<string> Sections { get; set; } = new();
    }

    public class DocumentUploadModel
    {
        public string Subject { get; set; } = string.Empty;
        public string Class { get; set; } = string.Empty;
        public string Section { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public List<IFormFile> Images { get; set; } = new();
        public DateTime UploadDate { get; set; } = DateTime.Now;
    }

    public class UploadedDocument
    {
        public int Id { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string Class { get; set; } = string.Empty;
        public string Section { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public string PdfFileName { get; set; } = string.Empty;
        public string PdfFilePath { get; set; } = string.Empty;
        public int PageCount { get; set; }
        public long FileSize { get; set; }
        public DateTime UploadedAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public bool IsProcessed { get; set; }
        public string ProcessingStatus { get; set; } = string.Empty; // "pending", "processing", "completed", "failed"
    }

    // Evaluator Dashboard Models
    public class EvaluatorDashboardViewModel
    {
        public string EvaluatorId { get; set; } = string.Empty;
        public string EvaluatorName { get; set; } = string.Empty;
        public List<AssignedSubjectViewModel> AssignedSubjects { get; set; } = new();
        public List<CompletedCopyViewModel> CompletedCopies { get; set; } = new();
        public EvaluatorStatisticsViewModel Statistics { get; set; } = new();
    }

    public class AssignedSubjectViewModel
    {
        public int Id { get; set; }
        public string Subject { get; set; } = string.Empty;
        public int TotalCopies { get; set; }
        public int CompletedCopies { get; set; }
        public int PendingCopies { get; set; }
        public double CompletionPercentage { get; set; }
        public string Status => CompletionPercentage == 100 ? "Completed" : CompletionPercentage > 0 ? "In Progress" : "Not Started";
        public string StatusClass => CompletionPercentage == 100 ? "badge-success" : CompletionPercentage > 0 ? "badge-warning" : "badge-secondary";
        public string ColorClass => CompletionPercentage == 100 ? "bg-success" : CompletionPercentage > 0 ? "bg-warning" : "bg-secondary";
        public DateTime AssignedDate { get; set; }
    }

    public class CompletedCopyViewModel
    {
        public int Id { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public int TotalMarks { get; set; }
        public decimal MarksObtained { get; set; }
        public decimal Percentage { get; set; }
        public int EvaluatedQuestions { get; set; }
        public int TotalQuestions { get; set; }
        public DateTime EvaluatedAt { get; set; }
        public string? PdfPath { get; set; }
        public string TimeAgo
        {
            get
            {
                var timeSpan = DateTime.Now - EvaluatedAt;
                if (timeSpan.TotalHours < 1) return "Less than an hour ago";
                if (timeSpan.TotalHours < 24) return $"{(int)timeSpan.TotalHours}h ago";
                if (timeSpan.TotalDays < 7) return $"{(int)timeSpan.TotalDays}d ago";
                return EvaluatedAt.ToString("MMM dd, yyyy");
            }
        }
    }

    public class EvaluatorStatisticsViewModel
    {
        public int TotalAssignedSubjects { get; set; }
        public int TotalCopiesToEvaluate { get; set; }
        public int CompletedEvaluations { get; set; }
        public int PendingEvaluations { get; set; }
        public double CompletionRate { get; set; }
        public double AverageMarksGiven { get; set; }
        public int EvaluationsThisWeek { get; set; }
        public int EvaluationsThisMonth { get; set; }
    }

    public class EvaluatorAssignment
    {
        public int Id { get; set; }
        public string EvaluatorId { get; set; } = string.Empty;
        public string EvaluatorName { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public int TotalCopies { get; set; }
        public int CompletedCopies { get; set; }
        public DateTime AssignedDate { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public bool IsActive { get; set; } = true;
    }
    public class RandomStudentViewModel
    {
        public int Id { get; set; }
        public string RollNumber { get; set; } = string.Empty;
        public string? StudentName { get; set; }
        public string? Class { get; set; }
        public string? Section { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string? PdfFilePath { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool IsEvaluated { get; set; }
    }
}
