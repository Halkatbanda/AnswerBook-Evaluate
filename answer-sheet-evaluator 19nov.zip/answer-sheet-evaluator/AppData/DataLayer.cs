﻿using System.Data;
using Microsoft.Data.SqlClient;

namespace AnswerSheetEvaluator.AppData
{
    public class DataLayer 
    {
        private readonly IConfiguration _configuration;
        private readonly string? ConnectionString;

        public DataLayer(IConfiguration configuration)
        {
            _configuration = configuration;
            ConnectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public async Task EnsureEvaluationDataExists(string subject, string rollNumber)
        {
            using SqlConnection connection = new(ConnectionString);
            using SqlCommand command = new("sp_GetEvaluationData", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Subject", subject);
            command.Parameters.AddWithValue("@RollNumber", rollNumber);

            await connection.OpenAsync();
            await command.ExecuteNonQueryAsync();
        }

        public DataSet LoginValidate(string UserID, string Password, string ipaddress)
        {
            DataSet ds = new();

            using (SqlConnection con = new(ConnectionString))
            using (SqlCommand cmd = new("EvaluatorLogin", con))
            using (SqlDataAdapter adapter = new(cmd))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UniqueId", UserID);
                cmd.Parameters.AddWithValue("@password", Password);
                cmd.Parameters.AddWithValue("@ipinfo", ipaddress);

                con.Open();
                adapter.Fill(ds);
            }

            return ds;
        }
    }
}
