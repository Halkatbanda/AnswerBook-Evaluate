-- Complete database schema for Answer Sheet Evaluator

-- Drop existing tables if they exist (for clean setup)
IF OBJECT_ID('EvaluationSummary', 'U') IS NOT NULL DROP TABLE EvaluationSummary;
IF OBJECT_ID('Evaluations', 'U') IS NOT NULL DROP TABLE Evaluations;
IF OBJECT_ID('AnswerSheets', 'U') IS NOT NULL DROP TABLE AnswerSheets;
IF OBJECT_ID('Subjects', 'U') IS NOT NULL DROP TABLE Subjects;
IF OBJECT_ID('Students', 'U') IS NOT NULL DROP TABLE Students;

-- Create Students table
CREATE TABLE Students (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    RollNumber NVARCHAR(50) NOT NULL UNIQUE,
    Name NVARCHAR(100),
    Email NVARCHAR(100),
    Phone NVARCHAR(20),
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE()
);

-- Create Subjects table
CREATE TABLE Subjects (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    SubjectCode NVARCHAR(50) NOT NULL UNIQUE,
    SubjectName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500),
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE()
);

-- Create AnswerSheets table
CREATE TABLE AnswerSheets (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Subject NVARCHAR(50) NOT NULL,
    RollNumber NVARCHAR(50) NOT NULL,
    AnswerSheetUrl NVARCHAR(500),
    QuestionPaperUrl NVARCHAR(500),
    TotalQuestions INT DEFAULT 20,
    ExamDate DATE,
    UploadedAt DATETIME2 DEFAULT GETDATE(),
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE(),
    UNIQUE(Subject, RollNumber)
);

-- Create Evaluations table
CREATE TABLE Evaluations (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Subject NVARCHAR(50) NOT NULL,
    RollNumber NVARCHAR(50) NOT NULL,
    QuestionNumber INT,
    EvaluationType NVARCHAR(20) NOT NULL, -- 'mark', 'tick', 'cross', 'line', 'BlankPage'
    Marks DECIMAL(4,2) DEFAULT 0,
    CoordinateX DECIMAL(8,4),
    CoordinateY DECIMAL(8,4),
    PageNumber INT,
    Comments NVARCHAR(500),
    EvaluatorId NVARCHAR(100), -- For future user management
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE(),
    INDEX IX_Evaluations_Subject_RollNumber (Subject, RollNumber),
    INDEX IX_Evaluations_QuestionNumber (QuestionNumber),
    INDEX IX_Evaluations_EvaluationType (EvaluationType)
);

-- Create EvaluationSummary table
CREATE TABLE EvaluationSummary (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Subject NVARCHAR(50) NOT NULL,
    RollNumber NVARCHAR(50) NOT NULL,
    TotalQuestions INT DEFAULT 20,
    TotalMarks DECIMAL(6,2) DEFAULT 0,
    EvaluatedQuestions INT DEFAULT 0,
    CompletionPercentage DECIMAL(5,2) DEFAULT 0,
    IsCompleted BIT DEFAULT 0,
    SubmittedAt DATETIME2,
    EvaluatorId NVARCHAR(100),
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE(),
    UNIQUE(Subject, RollNumber)
);

-- Insert sample subjects
INSERT INTO Subjects (SubjectCode, SubjectName, Description) VALUES
('MATH', 'Mathematics', 'Mathematics subject for all grades'),
('PHYS', 'Physics', 'Physics subject covering mechanics, thermodynamics, etc.'),
('CHEM', 'Chemistry', 'Chemistry subject covering organic and inorganic chemistry'),
('BIOL', 'Biology', 'Biology subject covering botany and zoology'),
('ENG', 'English', 'English language and literature'),
('HIST', 'History', 'World and regional history');

-- Insert sample students
INSERT INTO Students (RollNumber, Name, Email) VALUES
('2024001', 'John Doe', 'john.doe@example.com'),
('2024002', 'Jane Smith', 'jane.smith@example.com'),
('2024003', 'Mike Johnson', 'mike.johnson@example.com'),
('2024004', 'Sarah Wilson', 'sarah.wilson@example.com'),
('2024005', 'David Brown', 'david.brown@example.com'),
('2024006', 'Emily Davis', 'emily.davis@example.com'),
('2024007', 'Chris Miller', 'chris.miller@example.com'),
('2024008', 'Lisa Garcia', 'lisa.garcia@example.com'),
('2024009', 'Tom Anderson', 'tom.anderson@example.com'),
('2024010', 'Amy Taylor', 'amy.taylor@example.com');

-- Insert sample answer sheets
INSERT INTO AnswerSheets (Subject, RollNumber, AnswerSheetUrl, QuestionPaperUrl, TotalQuestions, ExamDate) VALUES
('mathematics', '2024001', '/uploads/pdfs/math_2024001.pdf', '/uploads/pdfs/math_question_paper.pdf', 20, '2024-01-15'),
('physics', '2024001', '/uploads/pdfs/physics_2024001.pdf', '/uploads/pdfs/physics_question_paper.pdf', 15, '2024-01-16'),
('mathematics', '2024002', '/uploads/pdfs/math_2024002.pdf', '/uploads/pdfs/math_question_paper.pdf', 20, '2024-01-15'),
('chemistry', '2024003', '/uploads/pdfs/chem_2024003.pdf', '/uploads/pdfs/chem_question_paper.pdf', 18, '2024-01-17'),
('biology', '2024004', '/uploads/pdfs/bio_2024004.pdf', '/uploads/pdfs/bio_question_paper.pdf', 20, '2024-01-18'),
('english', '2024005', '/uploads/pdfs/eng_2024005.pdf', '/uploads/pdfs/eng_question_paper.pdf', 25, '2024-01-19');

-- Insert sample evaluation summaries
INSERT INTO EvaluationSummary (Subject, RollNumber, TotalQuestions, TotalMarks, EvaluatedQuestions, CompletionPercentage, IsCompleted, SubmittedAt) VALUES
('mathematics', '2024001', 20, 85.5, 20, 100.0, 1, GETDATE()),
('physics', '2024001', 15, 67.0, 15, 100.0, 1, GETDATE()),
('mathematics', '2024002', 20, 92.0, 20, 100.0, 1, GETDATE()),
('chemistry', '2024003', 18, 78.5, 16, 88.9, 0, NULL),
('biology', '2024004', 20, 88.0, 20, 100.0, 1, GETDATE()),
('english', '2024005', 25, 0, 0, 0.0, 0, NULL);

-- Insert sample evaluation data
INSERT INTO Evaluations (Subject, RollNumber, QuestionNumber, EvaluationType, Marks, CoordinateX, CoordinateY, PageNumber) VALUES
-- Mathematics 2024001
('mathematics', '2024001', 1, 'mark', 4.5, 25.5, 30.2, 1),
('mathematics', '2024001', 1, 'tick', 0, 45.2, 35.8, 1),
('mathematics', '2024001', 2, 'mark', 3.0, 25.5, 55.4, 1),
('mathematics', '2024001', 3, 'mark', 5.0, 25.5, 75.6, 1),
('mathematics', '2024001', 4, 'mark', 2.5, 25.5, 30.2, 2),
('mathematics', '2024001', 4, 'cross', 0, 65.3, 35.1, 2),
-- Physics 2024001
('physics', '2024001', 1, 'mark', 4.0, 30.1, 25.5, 1),
('physics', '2024001', 2, 'mark', 3.5, 30.1, 50.2, 1),
('physics', '2024001', 3, 'mark', 5.0, 30.1, 75.8, 1),
-- Blank pages
('mathematics', '2024002', NULL, 'BlankPage', 0, NULL, NULL, 5),
('chemistry', '2024003', NULL, 'BlankPage', 0, NULL, NULL, 8);

GO
