-- =============================================
-- Answer Sheet Evaluator - Complete Database Schema
-- =============================================

USE master;
GO

-- Create database if it doesn't exist
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'AnswerSheetEvaluator')
BEGIN
    CREATE DATABASE AnswerSheetEvaluator;
END
GO

USE AnswerSheetEvaluator;
GO

-- =============================================
-- Drop existing objects (for clean setup)
-- =============================================

-- Drop stored procedures
IF OBJECT_ID('sp_GetAllEvaluations', 'P') IS NOT NULL DROP PROCEDURE sp_GetAllEvaluations;
IF OBJECT_ID('sp_GetAdminStatistics', 'P') IS NOT NULL DROP PROCEDURE sp_GetAdminStatistics;
IF OBJECT_ID('sp_GetEvaluationDetails', 'P') IS NOT NULL DROP PROCEDURE sp_GetEvaluationDetails;
IF OBJECT_ID('sp_DeleteEvaluation', 'P') IS NOT NULL DROP PROCEDURE sp_DeleteEvaluation;
IF OBJECT_ID('sp_GetEvaluationData', 'P') IS NOT NULL DROP PROCEDURE sp_GetEvaluationData;
IF OBJECT_ID('sp_GetExistingEvaluation', 'P') IS NOT NULL DROP PROCEDURE sp_GetExistingEvaluation;
IF OBJECT_ID('sp_ClearExistingEvaluation', 'P') IS NOT NULL DROP PROCEDURE sp_ClearExistingEvaluation;
IF OBJECT_ID('sp_InsertEvaluationData', 'P') IS NOT NULL DROP PROCEDURE sp_InsertEvaluationData;
IF OBJECT_ID('sp_InsertBlankPage', 'P') IS NOT NULL DROP PROCEDURE sp_InsertBlankPage;
IF OBJECT_ID('sp_InsertEvaluationSummary', 'P') IS NOT NULL DROP PROCEDURE sp_InsertEvaluationSummary;
IF OBJECT_ID('sp_GetEvaluationReport', 'P') IS NOT NULL DROP PROCEDURE sp_GetEvaluationReport;
IF OBJECT_ID('sp_GetSubjectStatistics', 'P') IS NOT NULL DROP PROCEDURE sp_GetSubjectStatistics;
IF OBJECT_ID('sp_BulkDeleteEvaluations', 'P') IS NOT NULL DROP PROCEDURE sp_BulkDeleteEvaluations;
IF OBJECT_ID('sp_GetDashboardStats', 'P') IS NOT NULL DROP PROCEDURE sp_GetDashboardStats;

-- Drop tables
IF OBJECT_ID('EvaluationSummary', 'U') IS NOT NULL DROP TABLE EvaluationSummary;
IF OBJECT_ID('Evaluations', 'U') IS NOT NULL DROP TABLE Evaluations;
IF OBJECT_ID('AnswerSheets', 'U') IS NOT NULL DROP TABLE AnswerSheets;
IF OBJECT_ID('Subjects', 'U') IS NOT NULL DROP TABLE Subjects;
IF OBJECT_ID('Students', 'U') IS NOT NULL DROP TABLE Students;
IF OBJECT_ID('SystemSettings', 'U') IS NOT NULL DROP TABLE SystemSettings;
IF OBJECT_ID('AuditLog', 'U') IS NOT NULL DROP TABLE AuditLog;

-- =============================================
-- Create Tables
-- =============================================

-- Students table
CREATE TABLE Students (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    RollNumber NVARCHAR(50) NOT NULL UNIQUE,
    Name NVARCHAR(100),
    Email NVARCHAR(100),
    Phone NVARCHAR(20),
    Class NVARCHAR(50),
    Section NVARCHAR(10),
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE(),
    
    INDEX IX_Students_RollNumber (RollNumber),
    INDEX IX_Students_Name (Name),
    INDEX IX_Students_Class (Class)
);

-- Subjects table
CREATE TABLE Subjects (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    SubjectCode NVARCHAR(50) NOT NULL UNIQUE,
    SubjectName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500),
    MaxMarks INT DEFAULT 100,
    PassingMarks INT DEFAULT 40,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE(),
    
    INDEX IX_Subjects_SubjectCode (SubjectCode),
    INDEX IX_Subjects_IsActive (IsActive)
);

-- AnswerSheets table
CREATE TABLE AnswerSheets (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Subject NVARCHAR(50) NOT NULL,
    RollNumber NVARCHAR(50) NOT NULL,
    AnswerSheetUrl NVARCHAR(500),
    QuestionPaperUrl NVARCHAR(500),
    TotalQuestions INT DEFAULT 20,
    ExamDate DATE,
    ExamDuration INT, -- in minutes
    UploadedAt DATETIME2 DEFAULT GETDATE(),
    UploadedBy NVARCHAR(100),
    FileSize BIGINT,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE(),
    
    CONSTRAINT UK_AnswerSheets_Subject_RollNumber UNIQUE(Subject, RollNumber),
    INDEX IX_AnswerSheets_Subject (Subject),
    INDEX IX_AnswerSheets_RollNumber (RollNumber),
    INDEX IX_AnswerSheets_ExamDate (ExamDate)
);

-- Evaluations table
CREATE TABLE Evaluations (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Subject NVARCHAR(50) NOT NULL,
    RollNumber NVARCHAR(50) NOT NULL,
    QuestionNumber INT,
    EvaluationType NVARCHAR(20) NOT NULL, -- 'mark', 'tick', 'cross', 'line', 'BlankPage'
    Marks DECIMAL(6,2) DEFAULT 0,
    CoordinateX DECIMAL(10,6),
    CoordinateY DECIMAL(10,6),
    PageNumber INT,
    Comments NVARCHAR(1000),
    EvaluatorId NVARCHAR(100),
    IsDeleted BIT DEFAULT 0,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE(),
    
    INDEX IX_Evaluations_Subject_RollNumber (Subject, RollNumber),
    INDEX IX_Evaluations_QuestionNumber (QuestionNumber),
    INDEX IX_Evaluations_EvaluationType (EvaluationType),
    INDEX IX_Evaluations_EvaluatorId (EvaluatorId),
    INDEX IX_Evaluations_CreatedAt (CreatedAt),
    
    CONSTRAINT CK_Evaluations_Marks CHECK (Marks >= 0 AND Marks <= 10),
    CONSTRAINT CK_Evaluations_EvaluationType CHECK (EvaluationType IN ('mark', 'tick', 'cross', 'line', 'BlankPage'))
);

-- EvaluationSummary table
CREATE TABLE EvaluationSummary (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Subject NVARCHAR(50) NOT NULL,
    RollNumber NVARCHAR(50) NOT NULL,
    TotalQuestions INT DEFAULT 20,
    TotalMarks DECIMAL(8,2) DEFAULT 0,
    EvaluatedQuestions INT DEFAULT 0,
    CompletionPercentage DECIMAL(5,2) DEFAULT 0,
    IsCompleted BIT DEFAULT 0,
    SubmittedAt DATETIME2,
    EvaluatorId NVARCHAR(100),
    EvaluationStartedAt DATETIME2,
    EvaluationDuration INT, -- in minutes
    Grade NVARCHAR(5),
    Remarks NVARCHAR(500),
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE(),
    
    CONSTRAINT UK_EvaluationSummary_Subject_RollNumber UNIQUE(Subject, RollNumber),
    INDEX IX_EvaluationSummary_Subject (Subject),
    INDEX IX_EvaluationSummary_RollNumber (RollNumber),
    INDEX IX_EvaluationSummary_IsCompleted (IsCompleted),
    INDEX IX_EvaluationSummary_SubmittedAt (SubmittedAt),
    INDEX IX_EvaluationSummary_EvaluatorId (EvaluatorId),
    
    CONSTRAINT CK_EvaluationSummary_CompletionPercentage CHECK (CompletionPercentage >= 0 AND CompletionPercentage <= 100)
);

-- SystemSettings table
CREATE TABLE SystemSettings (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    SettingKey NVARCHAR(100) NOT NULL UNIQUE,
    SettingValue NVARCHAR(1000),
    Description NVARCHAR(500),
    DataType NVARCHAR(20) DEFAULT 'string', -- 'string', 'int', 'bool', 'decimal'
    IsEditable BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    UpdatedAt DATETIME2 DEFAULT GETDATE()
);

-- AuditLog table
CREATE TABLE AuditLog (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    TableName NVARCHAR(100) NOT NULL,
    RecordId NVARCHAR(100),
    Action NVARCHAR(20) NOT NULL, -- 'INSERT', 'UPDATE', 'DELETE'
    OldValues NVARCHAR(MAX),
    NewValues NVARCHAR(MAX),
    UserId NVARCHAR(100),
    IPAddress NVARCHAR(45),
    UserAgent NVARCHAR(500),
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    
    INDEX IX_AuditLog_TableName (TableName),
    INDEX IX_AuditLog_Action (Action),
    INDEX IX_AuditLog_UserId (UserId),
    INDEX IX_AuditLog_CreatedAt (CreatedAt)
);

-- =============================================
-- Insert Default Data
-- =============================================

-- Insert system settings
INSERT INTO SystemSettings (SettingKey, SettingValue, Description, DataType) VALUES
('DefaultQuestionsCount', '20', 'Default number of questions per evaluation', 'int'),
('MaxMarksPerQuestion', '10', 'Maximum marks allowed per question', 'int'),
('PDFStoragePath', 'wwwroot/uploads/pdfs', 'Path to store PDF files', 'string'),
('MaxFileSizeMB', '50', 'Maximum file size in MB', 'int'),
('EnableAutoSave', 'true', 'Enable auto-save during evaluation', 'bool'),
('AutoSaveIntervalMinutes', '5', 'Auto-save interval in minutes', 'int'),
('DefaultPDFQuality', 'high', 'Default PDF quality setting', 'string'),
('AllowedFileTypes', '.pdf', 'Allowed file types for upload', 'string'),
('EvaluationTimeout', '120', 'Evaluation timeout in minutes', 'int'),
('EnableAuditLog', 'true', 'Enable audit logging', 'bool');

-- Insert subjects
INSERT INTO Subjects (SubjectCode, SubjectName, Description, MaxMarks, PassingMarks) VALUES
('MATH', 'Mathematics', 'Mathematics subject covering algebra, geometry, calculus', 100, 40),
('PHYS', 'Physics', 'Physics subject covering mechanics, thermodynamics, optics', 100, 40),
('CHEM', 'Chemistry', 'Chemistry subject covering organic and inorganic chemistry', 100, 40),
('BIOL', 'Biology', 'Biology subject covering botany, zoology, genetics', 100, 40),
('ENG', 'English', 'English language and literature', 100, 40),
('HIST', 'History', 'World and regional history', 100, 40),
('GEO', 'Geography', 'Physical and human geography', 100, 40),
('CS', 'Computer Science', 'Programming, algorithms, data structures', 100, 40);

-- Insert sample students
INSERT INTO Students (RollNumber, Name, Email, Class, Section) VALUES
('2024001', 'John Doe', 'john.doe@example.com', '12th', 'A'),
('2024002', 'Jane Smith', 'jane.smith@example.com', '12th', 'A'),
('2024003', 'Mike Johnson', 'mike.johnson@example.com', '12th', 'B'),
('2024004', 'Sarah Wilson', 'sarah.wilson@example.com', '12th', 'B'),
('2024005', 'David Brown', 'david.brown@example.com', '12th', 'A'),
('2024006', 'Emily Davis', 'emily.davis@example.com', '12th', 'C'),
('2024007', 'Chris Miller', 'chris.miller@example.com', '12th', 'C'),
('2024008', 'Lisa Garcia', 'lisa.garcia@example.com', '12th', 'A'),
('2024009', 'Tom Anderson', 'tom.anderson@example.com', '12th', 'B'),
('2024010', 'Amy Taylor', 'amy.taylor@example.com', '12th', 'C'),
('2024011', 'Robert Lee', 'robert.lee@example.com', '11th', 'A'),
('2024012', 'Maria Rodriguez', 'maria.rodriguez@example.com', '11th', 'B'),
('2024013', 'James Wilson', 'james.wilson@example.com', '11th', 'A'),
('2024014', 'Jennifer Brown', 'jennifer.brown@example.com', '11th', 'C'),
('2024015', 'Michael Davis', 'michael.davis@example.com', '11th', 'B');

-- Insert sample answer sheets
INSERT INTO AnswerSheets (Subject, RollNumber, AnswerSheetUrl, QuestionPaperUrl, TotalQuestions, ExamDate, ExamDuration) VALUES
('mathematics', '2024001', '/uploads/pdfs/math_2024001.pdf', '/uploads/pdfs/math_question_paper.pdf', 20, '2024-01-15', 180),
('physics', '2024001', '/uploads/pdfs/physics_2024001.pdf', '/uploads/pdfs/physics_question_paper.pdf', 15, '2024-01-16', 180),
('mathematics', '2024002', '/uploads/pdfs/math_2024002.pdf', '/uploads/pdfs/math_question_paper.pdf', 20, '2024-01-15', 180),
('chemistry', '2024003', '/uploads/pdfs/chem_2024003.pdf', '/uploads/pdfs/chem_question_paper.pdf', 18, '2024-01-17', 180),
('biology', '2024004', '/uploads/pdfs/bio_2024004.pdf', '/uploads/pdfs/bio_question_paper.pdf', 20, '2024-01-18', 180),
('english', '2024005', '/uploads/pdfs/eng_2024005.pdf', '/uploads/pdfs/eng_question_paper.pdf', 25, '2024-01-19', 180),
('mathematics', '2024006', '/uploads/pdfs/math_2024006.pdf', '/uploads/pdfs/math_question_paper.pdf', 20, '2024-01-20', 180),
('physics', '2024007', '/uploads/pdfs/physics_2024007.pdf', '/uploads/pdfs/physics_question_paper.pdf', 15, '2024-01-21', 180),
('chemistry', '2024008', '/uploads/pdfs/chem_2024008.pdf', '/uploads/pdfs/chem_question_paper.pdf', 18, '2024-01-22', 180),
('biology', '2024009', '/uploads/pdfs/bio_2024009.pdf', '/uploads/pdfs/bio_question_paper.pdf', 20, '2024-01-23', 180);

-- Insert sample evaluation summaries
INSERT INTO EvaluationSummary (Subject, RollNumber, TotalQuestions, TotalMarks, EvaluatedQuestions, CompletionPercentage, IsCompleted, SubmittedAt, Grade) VALUES
('mathematics', '2024001', 20, 85.5, 20, 100.0, 1, DATEADD(day, -5, GETDATE()), 'A'),
('physics', '2024001', 15, 67.0, 15, 100.0, 1, DATEADD(day, -4, GETDATE()), 'B'),
('mathematics', '2024002', 20, 92.0, 20, 100.0, 1, DATEADD(day, -3, GETDATE()), 'A+'),
('chemistry', '2024003', 18, 78.5, 16, 88.9, 0, NULL, NULL),
('biology', '2024004', 20, 88.0, 20, 100.0, 1, DATEADD(day, -2, GETDATE()), 'A'),
('english', '2024005', 25, 0, 0, 0.0, 0, NULL, NULL),
('mathematics', '2024006', 20, 76.0, 18, 90.0, 0, NULL, NULL),
('physics', '2024007', 15, 82.5, 15, 100.0, 1, DATEADD(day, -1, GETDATE()), 'A'),
('chemistry', '2024008', 18, 65.0, 12, 66.7, 0, NULL, NULL),
('biology', '2024009', 20, 91.5, 20, 100.0, 1, GETDATE(), 'A+');

-- Insert sample evaluation data
INSERT INTO Evaluations (Subject, RollNumber, QuestionNumber, EvaluationType, Marks, CoordinateX, CoordinateY, PageNumber, EvaluatorId) VALUES
-- Mathematics 2024001
('mathematics', '2024001', 1, 'mark', 4.5, 25.5, 30.2, 1, 'evaluator1'),
('mathematics', '2024001', 1, 'tick', 0, 45.2, 35.8, 1, 'evaluator1'),
('mathematics', '2024001', 2, 'mark', 3.0, 25.5, 55.4, 1, 'evaluator1'),
('mathematics', '2024001', 3, 'mark', 5.0, 25.5, 75.6, 1, 'evaluator1'),
('mathematics', '2024001', 4, 'mark', 2.5, 25.5, 30.2, 2, 'evaluator1'),
('mathematics', '2024001', 4, 'cross', 0, 65.3, 35.1, 2, 'evaluator1'),
('mathematics', '2024001', 5, 'mark', 4.0, 25.5, 55.4, 2, 'evaluator1'),
-- Physics 2024001
('physics', '2024001', 1, 'mark', 4.0, 30.1, 25.5, 1, 'evaluator1'),
('physics', '2024001', 2, 'mark', 3.5, 30.1, 50.2, 1, 'evaluator1'),
('physics', '2024001', 3, 'mark', 5.0, 30.1, 75.8, 1, 'evaluator1'),
('physics', '2024001', 4, 'mark', 2.5, 30.1, 25.5, 2, 'evaluator1'),
-- Mathematics 2024002
('mathematics', '2024002', 1, 'mark', 5.0, 25.5, 30.2, 1, 'evaluator2'),
('mathematics', '2024002', 2, 'mark', 4.5, 25.5, 55.4, 1, 'evaluator2'),
('mathematics', '2024002', 3, 'mark', 5.0, 25.5, 75.6, 1, 'evaluator2'),
-- Blank pages
('mathematics', '2024002', NULL, 'BlankPage', 0, NULL, NULL, 5, 'evaluator2'),
('chemistry', '2024003', NULL, 'BlankPage', 0, NULL, NULL, 8, 'evaluator1'),
('chemistry', '2024003', NULL, 'BlankPage', 0, NULL, NULL, 12, 'evaluator1');

GO

-- =============================================
-- Stored Procedures
-- =============================================

-- Get evaluation data for loading a paper
CREATE PROCEDURE sp_GetEvaluationData
    @Subject NVARCHAR(50),
    @RollNumber NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Get or create answer sheet record
    IF NOT EXISTS (SELECT 1 FROM AnswerSheets WHERE Subject = @Subject AND RollNumber = @RollNumber)
    BEGIN
        INSERT INTO AnswerSheets (Subject, RollNumber, AnswerSheetUrl, QuestionPaperUrl, TotalQuestions)
        VALUES (@Subject, @RollNumber, '/placeholder.pdf', '/placeholder.pdf', 20);
    END
    
    SELECT 
        Subject,
        RollNumber,
        AnswerSheetUrl,
        QuestionPaperUrl,
        TotalQuestions,
        ExamDate,
        ExamDuration
    FROM AnswerSheets
    WHERE Subject = @Subject AND RollNumber = @RollNumber;
END
GO

-- Get existing evaluation data
CREATE PROCEDURE sp_GetExistingEvaluation
    @Subject NVARCHAR(50),
    @RollNumber NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        Id,
        QuestionNumber,
        EvaluationType,
        Marks,
        CoordinateX,
        CoordinateY,
        PageNumber,
        Comments,
        CreatedAt
    FROM Evaluations
    WHERE Subject = @Subject 
      AND RollNumber = @RollNumber 
      AND IsDeleted = 0
    ORDER BY CreatedAt;
END
GO

-- Clear existing evaluation
CREATE PROCEDURE sp_ClearExistingEvaluation
    @Subject NVARCHAR(50),
    @RollNumber NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRANSACTION;
    
    BEGIN TRY
        -- Soft delete evaluations
        UPDATE Evaluations 
        SET IsDeleted = 1, UpdatedAt = GETDATE()
        WHERE Subject = @Subject AND RollNumber = @RollNumber;
        
        -- Delete evaluation summary
        DELETE FROM EvaluationSummary 
        WHERE Subject = @Subject AND RollNumber = @RollNumber;
        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

-- Insert evaluation data
CREATE PROCEDURE sp_InsertEvaluationData
    @Subject NVARCHAR(50),
    @RollNumber NVARCHAR(50),
    @QuestionNumber INT,
    @EvaluationType NVARCHAR(20),
    @Marks DECIMAL(6,2),
    @CoordinateX DECIMAL(10,6),
    @CoordinateY DECIMAL(10,6),
    @PageNumber INT,
    @Comments NVARCHAR(1000) = NULL,
    @EvaluatorId NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO Evaluations (
        Subject, RollNumber, QuestionNumber, EvaluationType, 
        Marks, CoordinateX, CoordinateY, PageNumber, Comments, EvaluatorId
    )
    VALUES (
        @Subject, @RollNumber, @QuestionNumber, @EvaluationType,
        @Marks, @CoordinateX, @CoordinateY, @PageNumber, @Comments, @EvaluatorId
    );
END
GO

-- Insert blank page
CREATE PROCEDURE sp_InsertBlankPage
    @Subject NVARCHAR(50),
    @RollNumber NVARCHAR(50),
    @PageNumber INT,
    @EvaluatorId NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO Evaluations (
        Subject, RollNumber, EvaluationType, PageNumber, EvaluatorId
    )
    VALUES (
        @Subject, @RollNumber, 'BlankPage', @PageNumber, @EvaluatorId
    );
END
GO

-- Insert evaluation summary
CREATE PROCEDURE sp_InsertEvaluationSummary
    @Subject NVARCHAR(50),
    @RollNumber NVARCHAR(50),
    @TotalQuestions INT,
    @TotalMarks DECIMAL(8,2),
    @SubmittedAt DATETIME2,
    @EvaluatorId NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @EvaluatedQuestions INT;
    DECLARE @CompletionPercentage DECIMAL(5,2);
    DECLARE @IsCompleted BIT;
    DECLARE @Grade NVARCHAR(5);
    
    -- Calculate evaluated questions
    SELECT @EvaluatedQuestions = COUNT(DISTINCT QuestionNumber)
    FROM Evaluations
    WHERE Subject = @Subject 
      AND RollNumber = @RollNumber 
      AND EvaluationType = 'mark'
      AND IsDeleted = 0;
    
    -- Calculate completion percentage
    SET @CompletionPercentage = CASE 
        WHEN @TotalQuestions > 0 THEN (@EvaluatedQuestions * 100.0) / @TotalQuestions 
        ELSE 0 
    END;
    
    -- Determine if completed
    SET @IsCompleted = CASE WHEN @EvaluatedQuestions = @TotalQuestions THEN 1 ELSE 0 END;
    
    -- Calculate grade based on marks
    SET @Grade = CASE 
        WHEN @TotalMarks >= 90 THEN 'A+'
        WHEN @TotalMarks >= 80 THEN 'A'
        WHEN @TotalMarks >= 70 THEN 'B+'
        WHEN @TotalMarks >= 60 THEN 'B'
        WHEN @TotalMarks >= 50 THEN 'C+'
        WHEN @TotalMarks >= 40 THEN 'C'
        ELSE 'F'
    END;
    
    -- Insert or update evaluation summary
    MERGE EvaluationSummary AS target
    USING (SELECT @Subject AS Subject, @RollNumber AS RollNumber) AS source
    ON (target.Subject = source.Subject AND target.RollNumber = source.RollNumber)
    WHEN MATCHED THEN
        UPDATE SET 
            TotalQuestions = @TotalQuestions,
            TotalMarks = @TotalMarks,
            EvaluatedQuestions = @EvaluatedQuestions,
            CompletionPercentage = @CompletionPercentage,
            IsCompleted = @IsCompleted,
            SubmittedAt = @SubmittedAt,
            EvaluatorId = @EvaluatorId,
            Grade = @Grade,
            UpdatedAt = GETDATE()
    WHEN NOT MATCHED THEN
        INSERT (Subject, RollNumber, TotalQuestions, TotalMarks, EvaluatedQuestions, 
                CompletionPercentage, IsCompleted, SubmittedAt, EvaluatorId, Grade)
        VALUES (@Subject, @RollNumber, @TotalQuestions, @TotalMarks, @EvaluatedQuestions,
                @CompletionPercentage, @IsCompleted, @SubmittedAt, @EvaluatorId, @Grade);
END
GO

-- Get all evaluations for admin dashboard
CREATE PROCEDURE sp_GetAllEvaluations
    @SearchTerm NVARCHAR(100) = NULL,
    @SubjectFilter NVARCHAR(50) = NULL,
    @StatusFilter NVARCHAR(20) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @Offset INT = (@PageNumber - 1) * @PageSize;
    
    WITH FilteredEvaluations AS (
        SELECT 
            es.Subject,
            es.RollNumber,
            s.Name as StudentName,
            es.TotalQuestions,
            es.EvaluatedQuestions,
            es.TotalMarks,
            es.CompletionPercentage,
            es.IsCompleted,
            es.SubmittedAt,
            es.Grade,
            ans.AnswerSheetUrl,
            es.CreatedAt,
            es.UpdatedAt,
            es.EvaluatorId
        FROM EvaluationSummary es
        LEFT JOIN Students s ON es.RollNumber = s.RollNumber
        LEFT JOIN AnswerSheets ans ON es.Subject = ans.Subject AND es.RollNumber = ans.RollNumber
        WHERE 1=1
            AND (@SearchTerm IS NULL OR @SearchTerm = '' OR 
                 es.RollNumber LIKE '%' + @SearchTerm + '%' OR 
                 s.Name LIKE '%' + @SearchTerm + '%')
            AND (@SubjectFilter IS NULL OR @SubjectFilter = 'all' OR es.Subject = @SubjectFilter)
            AND (@StatusFilter IS NULL OR @StatusFilter = 'all' OR
                 (@StatusFilter = 'completed' AND es.IsCompleted = 1) OR
                 (@StatusFilter = 'partial' AND es.IsCompleted = 0 AND es.EvaluatedQuestions > 0) OR
                 (@StatusFilter = 'not-started' AND es.EvaluatedQuestions = 0))
    )
    SELECT *,
           COUNT(*) OVER() as TotalCount
    FROM FilteredEvaluations
    ORDER BY CreatedAt DESC
    OFFSET @Offset ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- Get admin statistics
CREATE PROCEDURE sp_GetAdminStatistics
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Overall statistics
    SELECT 
        COUNT(*) as TotalEvaluations,
        SUM(CASE WHEN IsCompleted = 1 THEN 1 ELSE 0 END) as CompletedEvaluations,
        SUM(CASE WHEN IsCompleted = 0 AND EvaluatedQuestions > 0 THEN 1 ELSE 0 END) as InProgressEvaluations,
        SUM(CASE WHEN EvaluatedQuestions = 0 THEN 1 ELSE 0 END) as PendingEvaluations,
        ISNULL(AVG(CAST(TotalMarks as FLOAT)), 0) as AverageMarks,
        ISNULL(MAX(TotalMarks), 0) as HighestMarks,
        ISNULL(MIN(TotalMarks), 0) as LowestMarks,
        SUM(CASE WHEN CreatedAt >= DATEADD(week, -1, GETDATE()) THEN 1 ELSE 0 END) as NewEvaluationsThisWeek,
        SUM(CASE WHEN CreatedAt >= DATEADD(month, -1, GETDATE()) THEN 1 ELSE 0 END) as NewEvaluationsThisMonth,
        CASE WHEN COUNT(*) > 0 THEN 
            (SUM(CASE WHEN IsCompleted = 1 THEN 1 ELSE 0 END) * 100.0) / COUNT(*) 
        ELSE 0 END as CompletionRate
    FROM EvaluationSummary;
    
    -- Subject-wise statistics
    SELECT 
        es.Subject,
        subj.SubjectName,
        COUNT(*) as TotalEvaluations,
        SUM(CASE WHEN es.IsCompleted = 1 THEN 1 ELSE 0 END) as CompletedEvaluations,
        SUM(CASE WHEN es.IsCompleted = 0 THEN 1 ELSE 0 END) as PendingEvaluations,
        ISNULL(AVG(CAST(es.TotalMarks as FLOAT)), 0) as AverageMarks,
        ISNULL(MAX(es.TotalMarks), 0) as HighestMarks,
        ISNULL(MIN(es.TotalMarks), 0) as LowestMarks,
        CASE WHEN COUNT(*) > 0 THEN 
            (SUM(CASE WHEN es.IsCompleted = 1 THEN 1 ELSE 0 END) * 100.0) / COUNT(*) 
        ELSE 0 END as CompletionPercentage,
        COUNT(DISTINCT es.RollNumber) as TotalStudents
    FROM EvaluationSummary es
    LEFT JOIN Subjects subj ON es.Subject = subj.SubjectCode
    GROUP BY es.Subject, subj.SubjectName
    ORDER BY es.Subject;
    
    -- Recent activity (last 20 activities)
    SELECT TOP 20
        CASE 
            WHEN es.IsCompleted = 1 THEN 'Evaluation Completed'
            WHEN es.EvaluatedQuestions > 0 THEN 'Evaluation Updated'
            ELSE 'Evaluation Started'
        END as Action,
        es.Subject,
        es.RollNumber,
        s.Name as StudentName,
        CASE 
            WHEN es.IsCompleted = 1 THEN 'Completed'
            WHEN es.EvaluatedQuestions > 0 THEN 'In Progress'
            ELSE 'Started'
        END as Status,
        es.UpdatedAt as Timestamp,
        es.EvaluatorId,
        es.TotalMarks as Marks
    FROM EvaluationSummary es
    LEFT JOIN Students s ON es.RollNumber = s.RollNumber
    ORDER BY es.UpdatedAt DESC;
    
    -- Daily statistics for the last 30 days
    WITH DateRange AS (
        SELECT CAST(DATEADD(day, -29, GETDATE()) AS DATE) as Date
        UNION ALL
        SELECT DATEADD(day, 1, Date)
        FROM DateRange
        WHERE Date < CAST(GETDATE() AS DATE)
    )
    SELECT 
        dr.Date,
        ISNULL(COUNT(es.Id), 0) as TotalEvaluations,
        ISNULL(SUM(CASE WHEN es.IsCompleted = 1 THEN 1 ELSE 0 END), 0) as CompletedEvaluations,
        ISNULL(AVG(CAST(es.TotalMarks as FLOAT)), 0) as AverageMarks
    FROM DateRange dr
    LEFT JOIN EvaluationSummary es ON CAST(es.CreatedAt AS DATE) = dr.Date
    GROUP BY dr.Date
    ORDER BY dr.Date;
END
GO

-- Get evaluation details
CREATE PROCEDURE sp_GetEvaluationDetails
    @Subject NVARCHAR(50),
    @RollNumber NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Get evaluation summary
    SELECT 
        es.Subject,
        es.RollNumber,
        s.Name as StudentName,
        ans.AnswerSheetUrl,
        es.TotalQuestions,
        es.TotalMarks,
        es.EvaluatedQuestions,
        es.CompletionPercentage,
        es.IsCompleted,
        es.SubmittedAt,
        es.Grade,
        es.CreatedAt,
        es.UpdatedAt,
        es.EvaluatorId
    FROM EvaluationSummary es
    LEFT JOIN Students s ON es.RollNumber = s.RollNumber
    LEFT JOIN AnswerSheets ans ON es.Subject = ans.Subject AND es.RollNumber = ans.RollNumber
    WHERE es.Subject = @Subject AND es.RollNumber = @RollNumber;
    
    -- Get evaluation data
    SELECT 
        Id,
        QuestionNumber,
        EvaluationType,
        Marks,
        CoordinateX,
        CoordinateY,
        PageNumber,
        Comments,
        CreatedAt
    FROM Evaluations
    WHERE Subject = @Subject 
      AND RollNumber = @RollNumber 
      AND IsDeleted = 0
    ORDER BY CreatedAt;
END
GO

-- Delete evaluation
CREATE PROCEDURE sp_DeleteEvaluation
    @Subject NVARCHAR(50),
    @RollNumber NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRANSACTION;
    
    BEGIN TRY
        -- Soft delete from Evaluations table
        UPDATE Evaluations 
        SET IsDeleted = 1, UpdatedAt = GETDATE()
        WHERE Subject = @Subject AND RollNumber = @RollNumber;
        
        -- Delete from EvaluationSummary table
        DELETE FROM EvaluationSummary 
        WHERE Subject = @Subject AND RollNumber = @RollNumber;
        
        -- Log the deletion
        INSERT INTO AuditLog (TableName, RecordId, Action, UserId, CreatedAt)
        VALUES ('EvaluationSummary', @Subject + '_' + @RollNumber, 'DELETE', 'system', GETDATE());
        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

-- Get evaluation report
CREATE PROCEDURE sp_GetEvaluationReport
    @Subject NVARCHAR(50) = NULL,
    @StartDate DATETIME2 = NULL,
    @EndDate DATETIME2 = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        es.Subject,
        es.RollNumber,
        s.Name as StudentName,
        es.TotalQuestions,
        es.EvaluatedQuestions,
        es.TotalMarks,
        es.CompletionPercentage,
        es.Grade,
        es.SubmittedAt,
        es.CreatedAt,
        -- Question-wise marks as JSON-like string
        STUFF((
            SELECT ', Q' + CAST(e.QuestionNumber AS NVARCHAR) + ':' + CAST(SUM(e.Marks) AS NVARCHAR)
            FROM Evaluations e
            WHERE e.Subject = es.Subject 
              AND e.RollNumber = es.RollNumber 
              AND e.EvaluationType = 'mark'
              AND e.IsDeleted = 0
            GROUP BY e.QuestionNumber
            ORDER BY e.QuestionNumber
            FOR XML PATH('')
        ), 1, 2, '') as QuestionMarks
    FROM EvaluationSummary es
    LEFT JOIN Students s ON es.RollNumber = s.RollNumber
    WHERE (@Subject IS NULL OR es.Subject = @Subject)
      AND (@StartDate IS NULL OR es.CreatedAt >= @StartDate)
      AND (@EndDate IS NULL OR es.CreatedAt <= @EndDate)
    ORDER BY es.CreatedAt DESC;
    
    -- Summary statistics
    SELECT 
        COUNT(*) as TotalEvaluations,
        SUM(CASE WHEN IsCompleted = 1 THEN 1 ELSE 0 END) as CompletedEvaluations,
        ISNULL(AVG(CAST(TotalMarks as FLOAT)), 0) as AverageMarks,
        ISNULL(MAX(TotalMarks), 0) as HighestMarks,
        ISNULL(MIN(TotalMarks), 0) as LowestMarks,
        CASE WHEN COUNT(*) > 0 THEN 
            (SUM(CASE WHEN IsCompleted = 1 THEN 1 ELSE 0 END) * 100.0) / COUNT(*) 
        ELSE 0 END as CompletionRate
    FROM EvaluationSummary es
    WHERE (@Subject IS NULL OR es.Subject = @Subject)
      AND (@StartDate IS NULL OR es.CreatedAt >= @StartDate)
      AND (@EndDate IS NULL OR es.CreatedAt <= @EndDate);
END
GO

-- Bulk delete evaluations
CREATE PROCEDURE sp_BulkDeleteEvaluations
    @Subject NVARCHAR(50),
    @RollNumbers NVARCHAR(MAX) -- Comma-separated roll numbers
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRANSACTION;
    
    BEGIN TRY
        -- Create temp table for roll numbers
        CREATE TABLE #RollNumbers (RollNumber NVARCHAR(50));
        
        -- Split comma-separated roll numbers
        INSERT INTO #RollNumbers (RollNumber)
        SELECT LTRIM(RTRIM(value))
        FROM STRING_SPLIT(@RollNumbers, ',')
        WHERE LTRIM(RTRIM(value)) != '';
        
        -- Soft delete evaluations
        UPDATE e
        SET IsDeleted = 1, UpdatedAt = GETDATE()
        FROM Evaluations e
        INNER JOIN #RollNumbers rn ON e.RollNumber = rn.RollNumber
        WHERE e.Subject = @Subject;
        
        -- Delete evaluation summaries
        DELETE es
        FROM EvaluationSummary es
        INNER JOIN #RollNumbers rn ON es.RollNumber = rn.RollNumber
        WHERE es.Subject = @Subject;
        
        -- Log bulk deletion
        INSERT INTO AuditLog (TableName, RecordId, Action, UserId, CreatedAt)
        SELECT 'EvaluationSummary', @Subject + '_' + RollNumber, 'BULK_DELETE', 'system', GETDATE()
        FROM #RollNumbers;
        
        DROP TABLE #RollNumbers;
        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF OBJECT_ID('tempdb..#RollNumbers') IS NOT NULL
            DROP TABLE #RollNumbers;
        
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

-- Get dashboard statistics (optimized for dashboard)
CREATE PROCEDURE sp_GetDashboardStats
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Quick stats for dashboard cards
    SELECT 
        (SELECT COUNT(*) FROM EvaluationSummary) as TotalEvaluations,
        (SELECT COUNT(*) FROM EvaluationSummary WHERE IsCompleted = 1) as CompletedEvaluations,
        (SELECT COUNT(*) FROM EvaluationSummary WHERE IsCompleted = 0 AND EvaluatedQuestions > 0) as InProgressEvaluations,
        (SELECT COUNT(*) FROM EvaluationSummary WHERE EvaluatedQuestions = 0) as PendingEvaluations,
        (SELECT ISNULL(AVG(CAST(TotalMarks as FLOAT)), 0) FROM EvaluationSummary WHERE IsCompleted = 1) as AverageMarks,
        (SELECT COUNT(*) FROM EvaluationSummary WHERE CreatedAt >= DATEADD(week, -1, GETDATE())) as NewEvaluationsThisWeek,
        (SELECT COUNT(DISTINCT Subject) FROM EvaluationSummary) as TotalSubjects,
        (SELECT COUNT(DISTINCT RollNumber) FROM EvaluationSummary) as TotalStudents;
END
GO

-- Create indexes for better performance
CREATE NONCLUSTERED INDEX IX_Evaluations_Subject_RollNumber_Type 
ON Evaluations (Subject, RollNumber, EvaluationType) 
INCLUDE (QuestionNumber, Marks, IsDeleted);

CREATE NONCLUSTERED INDEX IX_EvaluationSummary_CreatedAt_Completed 
ON EvaluationSummary (CreatedAt, IsCompleted) 
INCLUDE (Subject, RollNumber, TotalMarks);

CREATE NONCLUSTERED INDEX IX_Students_RollNumber_Name 
ON Students (RollNumber) 
INCLUDE (Name, Email, Class);

PRINT 'Database schema and stored procedures created successfully!';
